# AgriFresh – Agriculture Product Delivery System

**AgriFresh** is a production-grade, modular, and beginner-friendly full-stack web application designed to connect local farmers directly with household consumers. It eliminates middlemen by offering transparent farm-to-table delivery, real-time live order dispatch tracking, multi-role access control (Customer, Farmer/Seller, Admin), inventory control, and simulated payments.

---

## 📑 Table of Contents
1. [Project Overview & Key Features](#-project-overview--key-features)
2. [Technology Stack](#-technology-stack)
3. [Architecture & Layered Design](#-architecture--layered-design)
4. [Database Design & ER Relationships](#-database-design--er-relationships)
5. [Complete Project Folder Structure](#-complete-project-folder-structure)
6. [Pre-Configured Test Credentials](#-pre-configured-test-credentials)
7. [MySQL Database Setup Instructions](#-mysql-database-setup-instructions)
8. [Steps to Run the Project](#-steps-to-run-the-project)
   - [Running with Maven / CLI](#running-with-maven--cli)
   - [Running in IntelliJ IDEA](#running-in-intellij-idea)
   - [Running in Eclipse / Spring Tool Suite](#running-in-eclipse--spring-tool-suite)
   - [Running in VS Code](#running-in-vs-code)
9. [REST API Documentation](#-rest-api-documentation)
10. [Frontend Pages Overview](#-frontend-pages-overview)
11. [Verification & Test Cases](#-verification--test-cases)
12. [Common Errors & Troubleshooting](#-common-errors--troubleshooting)
13. [Viva / Final-Year Project Presentation Guide](#-viva--final-year-project-presentation-guide)

---

## 🌾 Project Overview & Key Features

* **Direct Farm-to-Consumer Marketplace:** Real farmers list fresh harvest produce (Vegetables, Fruits, Grains, Pulses, Dairy, Spices, Honey, Organic Items, Seeds) with units (`kg`, `litre`, `bunch`, `packet`, etc.).
* **Role-Based Access Control (RBAC):** Three roles: `CUSTOMER`, `SELLER`, and `ADMIN`, secured with Spring Security, BCrypt password hashing, and JWT tokens.
* **Smart Search & Multi-Criteria Filtering:** Search by produce name, filter by category, price range, availability (in-stock only), and sort by price (low-high, high-low) or newest harvest.
* **Stock & Inventory Protection:** Backend cart calculations prevent customers from ordering more quantity than available stock in real-time.
* **Shopping Cart & Checkout:** Persistent backend cart, automatic free delivery threshold calculation (Free delivery above ₹500, else ₹40 standard fee).
* **Live 5-Stage Delivery Tracking:** Visual animated timeline with milestones:  
  `Order Placed` ➔ `Confirmed` ➔ `Packed` ➔ `Out for Delivery` ➔ `Delivered`.
* **Mock Payment Gateway:** Supports Cash on Delivery (COD), UPI (with QR code and VPA simulation), Credit/Debit Card (mock sandbox approval without storing sensitive card details), and Net Banking.
* **Farmer/Seller Command Center:** Product management (Add/Edit/Delete), inventory stock updating, received order tracking with status transition controls, and sales revenue analytics.
* **Customer Dashboard:** Order history, live tracking, address book, profile updater, and total spending analytics.
* **Super-Admin Control Panel:** Platform user moderation (activate/deactivate customer or seller accounts), category creator/editor, and system-wide order logs.

---

## 🛠 Technology Stack

| Layer | Technologies Used |
| :--- | :--- |
| **Frontend** | HTML5, CSS3 (Custom Responsive Natural Green Theme), Modern JavaScript (Fetch API, ES6+) |
| **Backend** | Java 17, Spring Boot 3.2.5 (Spring Web, Spring Security, Spring Data JPA, Bean Validation) |
| **Security** | Spring Security 6, JJWT 0.11.5, BCrypt Password Encoder |
| **Database** | MySQL 8.0+ (with optional H2 in-memory fallback) |
| **ORM / Persistence** | Hibernate / Spring Data JPA |
| **Build Tool** | Apache Maven 3.8+ |
| **Protocol** | RESTful JSON APIs |

---

## 🏛 Architecture & Layered Design

The backend adheres strictly to layered enterprise architecture:
```
[Client (HTML5/CSS3/JS)] 
          │ (JSON via REST API)
          ▼
[Controller Layer]       --> com.agrifresh.controller
          │
[Security / Filters]     --> com.agrifresh.security (JwtUtils, AuthTokenFilter)
          │
[Service Layer]          --> com.agrifresh.service & service.impl
          │
[Repository Layer]       --> com.agrifresh.repository (Spring Data JPA)
          │
[Entity Layer (ORM)]     --> com.agrifresh.entity
          ▼
   [MySQL Database]      --> agrifresh_db
```

---

## 🗄 Database Design & ER Relationships

```mermaid
erDiagram
    USERS ||--o| SELLERS : "has farm profile"
    USERS ||--o| CARTS : "owns"
    USERS ||--o{ ORDERS : "places"
    USERS ||--o{ REVIEWS : "writes"
    
    SELLERS ||--o{ PRODUCTS : "produces"
    CATEGORIES ||--o{ PRODUCTS : "classifies"
    
    CARTS ||--o{ CART_ITEMS : "contains"
    PRODUCTS ||--o{ CART_ITEMS : "included in"
    
    ORDERS ||--o{ ORDER_ITEMS : "composed of"
    PRODUCTS ||--o{ ORDER_ITEMS : "referenced in"
    SELLERS ||--o{ ORDER_ITEMS : "fulfilled by"
    
    ORDERS ||--o| PAYMENTS : "paid via"
    PRODUCTS ||--o{ REVIEWS : "evaluated in"
```

### Key Tables & Constraints
* `users`: `id` (PK), `email` (Unique), `password` (BCrypt), `role` (`ROLE_CUSTOMER`, `ROLE_SELLER`, `ROLE_ADMIN`), `active` (Boolean).
* `sellers`: `id` (PK), `user_id` (FK ➔ `users.id`, Unique), `farm_name`, `farm_address`.
* `categories`: `id` (PK), `name` (Unique), `description`, `image_url`.
* `products`: `id` (PK), `seller_id` (FK ➔ `sellers.id`), `category_id` (FK ➔ `categories.id`), `price`, `stock_quantity`, `unit`, `available`.
* `carts`: `id` (PK), `user_id` (FK ➔ `users.id`, Unique).
* `cart_items`: `id` (PK), `cart_id` (FK ➔ `carts.id`), `product_id` (FK ➔ `products.id`), `quantity`.
* `orders`: `id` (PK), `order_number` (Unique), `customer_id` (FK ➔ `users.id`), `total_amount`, `delivery_charge`, `order_status`.
* `order_items`: `id` (PK), `order_id` (FK ➔ `orders.id`), `product_id` (FK), `seller_id` (FK), `quantity`, `price`, `subtotal`.
* `payments`: `id` (PK), `order_id` (FK ➔ `orders.id`, Unique), `payment_method`, `payment_status`, `transaction_id`.
* `reviews`: `id` (PK), `product_id` (FK), `customer_id` (FK), `rating` (1 to 5), `comment`.

---

## 📁 Complete Project Folder Structure

```
agrifresh/
├── pom.xml                                      # Maven dependencies & build setup
├── README.md                                    # Comprehensive system documentation
├── database/
│   ├── schema.sql                               # MySQL DDL table creation script
│   └── data.sql                                 # Seed data script
└── src/
    └── main/
        ├── java/
        │   └── com/
        │       └── agrifresh/
        │           ├── AgriFreshApplication.java # Spring Boot entry point
        │           ├── config/
        │           │   ├── DataInitializer.java  # Auto-seeds categories, users, products
        │           │   └── WebMvcConfig.java    # Configures static file serving & root routing
        │           ├── controller/
        │           │   ├── AdminController.java
        │           │   ├── AuthController.java
        │           │   ├── CartController.java
        │           │   ├── CategoryController.java
        │           │   ├── CustomerController.java
        │           │   ├── OrderController.java
        │           │   ├── PaymentController.java
        │           │   ├── ProductController.java
        │           │   ├── ReviewController.java
        │           │   └── SellerController.java
        │           ├── dto/
        │           │   ├── ApiResponse.java
        │           │   ├── AuthRequest.java
        │           │   ├── AuthResponse.java
        │           │   ├── CartDto.java
        │           │   ├── CartItemDto.java
        │           │   ├── CartItemRequest.java
        │           │   ├── CategoryDto.java
        │           │   ├── CategoryRequest.java
        │           │   ├── DashboardStatsDto.java
        │           │   ├── OrderDto.java
        │           │   ├── OrderItemDto.java
        │           │   ├── OrderRequest.java
        │           │   ├── OrderStatusUpdateRequest.java
        │           │   ├── PaymentDto.java
        │           │   ├── PaymentRequest.java
        │           │   ├── ProductDto.java
        │           │   ├── ProductRequest.java
        │           │   ├── ProfileUpdateRequest.java
        │           │   ├── RegisterRequest.java
        │           │   ├── ReviewDto.java
        │           │   ├── ReviewRequest.java
        │           │   └── UserDto.java
        │           ├── entity/
        │           │   ├── Cart.java
        │           │   ├── CartItem.java
        │           │   ├── Category.java
        │           │   ├── Order.java
        │           │   ├── OrderItem.java
        │           │   ├── OrderStatus.java      # Enum
        │           │   ├── Payment.java
        │           │   ├── PaymentMethod.java    # Enum
        │           │   ├── PaymentStatus.java    # Enum
        │           │   ├── Product.java
        │           │   ├── Review.java
        │           │   ├── Role.java             # Enum
        │           │   ├── Seller.java
        │           │   └── User.java
        │           ├── exception/
        │           │   ├── BadRequestException.java
        │           │   ├── GlobalExceptionHandler.java # @RestControllerAdvice
        │           │   ├── ResourceNotFoundException.java
        │           │   └── UnauthorizedException.java
        │           ├── repository/
        │           │   ├── CartItemRepository.java
        │           │   ├── CartRepository.java
        │           │   ├── CategoryRepository.java
        │           │   ├── OrderItemRepository.java
        │           │   ├── OrderRepository.java
        │           │   ├── PaymentRepository.java
        │           │   ├── ProductRepository.java
        │           │   ├── ReviewRepository.java
        │           │   ├── SellerRepository.java
        │           │   └── UserRepository.java
        │           ├── security/
        │           │   ├── AuthEntryPointJwt.java
        │           │   ├── AuthTokenFilter.java
        │           │   ├── JwtUtils.java
        │           │   ├── SecurityConfig.java
        │           │   ├── UserDetailsImpl.java
        │           │   └── UserDetailsServiceImpl.java
        │           ├── service/
        │           │   ├── AuthService.java
        │           │   ├── CartService.java
        │           │   ├── CategoryService.java
        │           │   ├── OrderService.java
        │           │   ├── PaymentService.java
        │           │   ├── ProductService.java
        │           │   ├── ReviewService.java
        │           │   └── UserService.java
        │           └── service/impl/
        │               ├── AuthServiceImpl.java
        │               ├── CartServiceImpl.java
        │               ├── CategoryServiceImpl.java
        │               ├── OrderServiceImpl.java
        │               ├── PaymentServiceImpl.java
        │               ├── ProductServiceImpl.java
        │               ├── ReviewServiceImpl.java
        │               └── UserServiceImpl.java
        └── resources/
            ├── application.properties           # MySQL connection and JWT parameters
            └── static/                          # HTML5, CSS3, JS Frontend
                ├── css/
                │   └── style.css                # Agriculture Theme CSS variables & components
                ├── js/
                │   └── api.js                   # REST API client & local session storage
                ├── index.html                   # 1. Landing Page & Hero
                ├── login.html                   # 2. Login Page (with quick-fill demo buttons)
                ├── register.html                # 3. Registration (Customer & Farmer toggle)
                ├── products.html                # 4. Marketplace catalog & filters
                ├── product-details.html         # 5. Product detail view & reviews
                ├── cart.html                    # 6. Interactive shopping cart
                ├── checkout.html                # 7. Delivery information & payment select
                ├── payment.html                 # 8. Mock payment gateway (UPI, Card, NetBanking)
                ├── order-success.html           # 9. Order confirmation & invoice receipt
                ├── order-tracking.html          # 10. Live 5-stage progress timeline
                ├── customer-dashboard.html      # 11. Customer portal & order history
                ├── seller-dashboard.html        # 12. Farmer command center & KPI stats
                ├── add-product.html             # 13. Add new produce listing
                ├── edit-product.html            # 14. Edit produce & update stock
                ├── seller-orders.html           # 15. Manage received farm orders
                ├── profile.html                 # 16. Profile settings & farm credentials
                └── admin-dashboard.html         # 17. Administrator moderation & categories
```

---

## 🔑 Pre-Configured Test Credentials

The system includes automatic seeding via `DataInitializer.java`. On the very first run, these test accounts are created with encrypted BCrypt passwords:

| Role | Email | Password | Details |
| :--- | :--- | :--- | :--- |
| **Customer** | `rahul@gmail.com` | `customer123` | Household buyer in Pune, MH. Preloaded with past order `ORD-20261007-DEMO`. |
| **Customer** | `priya@gmail.com` | `customer123` | Organic consumer in Bangalore, KA. |
| **Farmer / Seller** | `ramesh@farm.com` | `seller123` | Green Valley Organic Farm, Nashik (Produces Tomatoes, Apples, A2 Ghee, Basmati Rice). |
| **Farmer / Seller** | `sita@farm.com` | `seller123` | Sunrise Agro Farms, Pune (Produces Spinach, Oranges, Toor Dal, Raw Honey). |
| **Admin** | `admin@agrifresh.com` | `admin123` | System Administrator with full management permissions. |

> **Pro Tip:** On `login.html`, click the **"Customer"**, **"Farmer / Seller"**, or **"Admin"** quick buttons to auto-populate credentials instantly.

---

## 🗄 MySQL Database Setup Instructions

1. **Start MySQL Server:**  
   Ensure MySQL service is running on port `3306` (via MySQL Workbench, XAMPP, WampServer, or Windows Services).

2. **Create Database (Optional):**  
   The application connection string has `createDatabaseIfNotExist=true`. If you prefer manual creation, run:
   ```sql
   CREATE DATABASE agrifresh_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```

3. **Check Credentials in `src/main/resources/application.properties`:**
   ```properties
   spring.datasource.url=jdbc:mysql://localhost:3306/agrifresh_db?createDatabaseIfNotExist=true&useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC
   spring.datasource.username=root
   spring.datasource.password=bhanu@123
   ```
   *Change `root`/`root` to match your local MySQL username and password if different.*

4. **Instant In-Memory Demo Fallback (Optional):**  
   If MySQL is not installed on the presentation laptop, you can switch to H2 in-memory database by uncommenting the H2 lines in `application.properties`:
   ```properties
   spring.datasource.url=jdbc:h2:mem:agrifresh_db;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE
   spring.datasource.driver-class-name=org.h2.Driver
   spring.datasource.username=sa
   spring.datasource.password=
   ```

---

## 🚀 Steps to Run the Project

### Running with Maven / CLI
1. Open PowerShell or Command Prompt in the project folder:
   ```cmd
   cd C:\Users\vaish\.gemini\antigravity\scratch\agrifresh
   ```
2. Build and run:
   ```cmd
   mvn clean spring-boot:run
   ```
3. Open your web browser and navigate to:
   ```
   http://localhost:8080/
   ```

### Running in IntelliJ IDEA
1. Open IntelliJ IDEA ➔ Select **File** ➔ **Open**.
2. Browse to `C:\Users\vaish\.gemini\antigravity\scratch\agrifresh` and select the `pom.xml`.
3. Choose **Open as Project**.
4. Allow IntelliJ to download Maven dependencies.
5. In the Project Explorer, expand `src/main/java/com/agrifresh/`.
6. Right-click on `AgriFreshApplication.java` and click **Run 'AgriFreshApplication'**.
7. Access `http://localhost:8080/` in your browser.

### Running in Eclipse / Spring Tool Suite (STS)
1. Select **File** ➔ **Import** ➔ **Existing Maven Projects**.
2. Select root directory `C:\Users\vaish\.gemini\antigravity\scratch\agrifresh`.
3. Finish import and wait for Maven build.
4. Right-click the project ➔ **Run As** ➔ **Spring Boot App**.

### Running in VS Code
1. Open folder `C:\Users\vaish\.gemini\antigravity\scratch\agrifresh`.
2. Ensure the **Extension Pack for Java** and **Spring Boot Extension Pack** are installed.
3. Open `AgriFreshApplication.java` and click **Run** above `main()`.

---

## 📡 REST API Documentation

### 1. Authentication APIs (`/api/auth`)
* `POST /api/auth/register` – Register a new user (Customer or Farmer/Seller).
* `POST /api/auth/login` – Authenticate with email and password; returns JWT token and role profile.
* `POST /api/auth/logout` – Clear user session.

### 2. Products APIs (`/api/products`)
* `GET /api/products` – Public list of all available farm produce.
* `GET /api/products/{id}` – Get detailed produce information.
* `GET /api/products/search?keyword=&categoryId=&minPrice=&maxPrice=&availableOnly=&sortBy=` – Filtered multi-criteria search.
* `GET /api/products/category/{categoryId}` – Produce by specific agricultural category.
* `POST /api/products` – **[SELLER, ADMIN]** List new produce.
* `PUT /api/products/{id}` – **[SELLER, ADMIN]** Update price, stock, or description.
* `DELETE /api/products/{id}` – **[SELLER, ADMIN]** Remove produce from catalog.

### 3. Categories APIs (`/api/categories`)
* `GET /api/categories` – Get all 10 agricultural categories.
* `GET /api/categories/{id}` – Get category by ID.
* `POST /api/categories` – **[ADMIN]** Add a new category.
* `PUT /api/categories/{id}` – **[ADMIN]** Update category.
* `DELETE /api/categories/{id}` – **[ADMIN]** Delete category.

### 4. Shopping Cart APIs (`/api/cart`)
* `GET /api/cart` – **[CUSTOMER]** Retrieve customer's active cart with subtotal and delivery charge.
* `POST /api/cart/items` – **[CUSTOMER]** Add product to cart with quantity validation.
* `PUT /api/cart/items/{id}` – **[CUSTOMER]** Update quantity with stock limit check.
* `DELETE /api/cart/items/{id}` – **[CUSTOMER]** Remove item from cart.
* `DELETE /api/cart/clear` – **[CUSTOMER]** Clear entire cart.

### 5. Orders & Tracking APIs (`/api/orders`)
* `POST /api/orders` – **[CUSTOMER]** Place order; validates stock, deducts inventory, empties cart, and generates unique Order ID (`ORD-YYYYMMDD-XXXX`).
* `GET /api/orders` – **[CUSTOMER]** Retrieve logged-in customer's orders.
* `GET /api/orders/{id}` – Get order details by ID.
* `GET /api/orders/track/{orderNumber}` – Get live delivery timeline for order number.
* `PUT /api/orders/{id}/status` – **[SELLER, ADMIN]** Advance order status (`ORDER_PLACED`, `CONFIRMED`, `PACKED`, `OUT_FOR_DELIVERY`, `DELIVERED`, `CANCELLED`).
* `DELETE /api/orders/{id}/cancel` – **[CUSTOMER, ADMIN]** Cancel order; restores product stock back to farm inventory.

### 6. Payments APIs (`/api/payments`)
* `POST /api/payments` – Process mock payment (COD, UPI, Card, Net Banking); generates transaction ID.
* `GET /api/payments/{orderId}` – Get payment details for an order.

### 7. Farmer/Seller APIs (`/api/seller`)
* `GET /api/seller/products` – **[SELLER]** Products listed by logged-in farmer.
* `GET /api/seller/orders` – **[SELLER]** Orders containing farmer's produce.
* `GET /api/seller/dashboard` – **[SELLER]** Total products, orders, pending dispatch, and total earned revenue.

### 8. Customer APIs (`/api/customer`)
* `GET /api/customer/profile` – **[CUSTOMER]** Get customer profile.
* `PUT /api/customer/profile` – **[CUSTOMER]** Update contact & delivery address.
* `GET /api/customer/orders` – **[CUSTOMER]** Order history.
* `GET /api/customer/dashboard` – **[CUSTOMER]** Summary KPI stats.

### 9. Admin APIs (`/api/admin`)
* `GET /api/admin/users` – **[ADMIN]** View all platform users.
* `PUT /api/admin/users/{id}/status` – **[ADMIN]** Activate or deactivate user.
* `GET /api/admin/sellers` – **[ADMIN]** View all registered farmers.
* `GET /api/admin/orders` – **[ADMIN]** Audit all platform orders.
* `GET /api/admin/dashboard` – **[ADMIN]** System analytics (customers, sellers, products, total revenue).

### 10. Reviews APIs (`/api/products/{productId}/reviews`)
* `GET /api/products/{productId}/reviews` – Customer reviews for produce.
* `POST /api/products/{productId}/reviews` – **[CUSTOMER]** Post 1 to 5 star rating and feedback.

---

## 🖥 Frontend Pages Overview

| File | Page Name | Primary Features |
| :--- | :--- | :--- |
| `index.html` | Home Page | Hero banner, category cards, featured harvest produce, farm-direct advantages, customer reviews. |
| `login.html` | Sign In | Authentication with role redirection and quick demo test buttons. |
| `register.html` | Register | Dynamic tab switcher for Customer vs Farmer registration (reveals farm credentials). |
| `products.html` | Marketplace | Search bar, category filters, price range filter, sorting options, stock status, Add to Cart. |
| `product-details.html` | Product View | High-res image, farm origin badge, stock meter, quantity selector, reviews list, Add Review form. |
| `cart.html` | Shopping Cart | Item quantity controls (+ / -), subtotal, Free Delivery progress bar, remove item, proceed to checkout. |
| `checkout.html` | Checkout | Delivery address inputs (prefilled from profile), order summary, payment mode selector. |
| `payment.html` | Mock Gateway | Simulated UPI QR scanner, Card payment sandbox, Net Banking, instant approval simulation. |
| `order-success.html` | Order Confirmed | Order ID, delivery ETA, itemized receipt breakdown, Print Receipt button, Track Order button. |
| `order-tracking.html` | Live Delivery Tracking | Search by Order ID, 5-step visual milestone progress bar with active pulse animations. |
| `customer-dashboard.html` | Customer Portal | Sidebar navigation, order summary KPI cards, order history table with instant tracking links. |
| `seller-dashboard.html` | Farmer Dashboard | Inventory catalog table, revenue KPI cards, quick stock updater, Delete and Edit actions. |
| `add-product.html` | Add Produce | Category select, unit selector (`kg`, `litre`, `bunch`), live image preview, publish button. |
| `edit-product.html` | Edit Produce | Pre-populated form to update prices, stock, and descriptions. |
| `seller-orders.html` | Order Fulfillment | Order list for farmer's items with dropdown status updates (`CONFIRMED` ➔ `PACKED` ➔ `OUT_FOR_DELIVERY`). |
| `profile.html` | Profile Settings | Update contact details, delivery address, and farm land records. |
| `admin-dashboard.html` | Admin Panel | Platform analytics, user active/deactivate toggle, category creation modal, order logs. |

---

## 🧪 Verification & Test Cases

| Test Case | Steps to Test | Expected Result |
| :--- | :--- | :--- |
| **TC-01: User Registration** | Go to `register.html`, choose "Farmer Account", enter Farm name & address, submit. | Account created, redirected to `seller-dashboard.html`. |
| **TC-02: Role-Based Redirection** | Go to `login.html`, click "Farmer / Seller" quick button, click Login. | Logged in as Ramesh Patil, redirected to `seller-dashboard.html`. |
| **TC-03: Stock Validation in Cart** | Open `product-details.html?id=1` (stock = 150 kg). Try ordering 151 kg. | System blocks request with error: *"Requested quantity exceeds available stock"*. |
| **TC-04: Free Delivery Calculation** | Add ₹400 worth of produce in cart ➔ Delivery fee is ₹40. Add ₹150 more ➔ Delivery fee becomes **FREE** (Total > ₹500). | Correct delivery fee calculated on backend and displayed in UI. |
| **TC-05: Order Placement & Inventory** | Note stock of product (e.g. 150 kg). Order 5 kg at checkout. | Unique Order ID generated (e.g. `ORD-20261007-XXXX`), product stock decrements to 145 kg. |
| **TC-06: Live Delivery Tracking** | Visit `order-tracking.html` with order number `ORD-20261007-DEMO`. | Visual 5-step timeline displays `CONFIRMED` step highlighted with active pulse. |
| **TC-07: Seller Status Progression** | Login as Seller `ramesh@farm.com`, go to `seller-orders.html`, update order to `PACKED`. | Status saved in MySQL; customer tracking timeline instantly advances to `PACKED`. |
| **TC-08: Order Cancellation** | On `customer-dashboard.html`, click "Cancel" on a placed order. | Order status updates to `CANCELLED`, product quantities are returned to farm inventory. |
| **TC-09: Admin User Moderation** | Login as `admin@agrifresh.com`, go to `admin-dashboard.html`, deactivate a customer. | Status updates to `Deactivated`; user cannot log in until reactivated. |

---

## ⚠️ Common Errors & Troubleshooting

1. **Error: `Communications link failure` / `Connection refused: connect`**
   * *Cause:* MySQL server is not started or running on a port other than 3306.
   * *Fix:* Start MySQL service in XAMPP or Windows Services, or switch to H2 in-memory DB in `application.properties`.

2. **Error: `Access denied for user 'root'@'localhost'`**
   * *Cause:* MySQL password in `application.properties` does not match your local MySQL root password.
   * *Fix:* Open `src/main/resources/application.properties` and change `spring.datasource.password=root` to your actual password.

3. **Error: `Port 8080 is already in use`**
   * *Cause:* Another program (such as Apache, Tomcat, or a previous Spring Boot run) is occupying port 8080.
   * *Fix:* Change `server.port=8081` in `application.properties`, or stop the process using `netstat -ano | findstr 8080`.

4. **Error: `401 Unauthorized` on API Calls**
   * *Cause:* Expired or missing JWT token.
   * *Fix:* Log out and log back in from `login.html` to refresh token in `localStorage`.

---

## 🎓 Viva / Final-Year Project Presentation Guide

### 1. What problem does AgriFresh solve?
* **Middlemen exploitation:** Traditional agricultural supply chains involve multiple commission agents, shrinking farmer profits while increasing retail costs. AgriFresh allows farmers to list produce directly, receive higher margins, and offers consumers fresher harvest with verifiable origins.

### 2. How is security implemented?
* Stateless REST API authentication using **Spring Security 6** and **JWT (JSON Web Tokens)**.
* Passwords are never stored in plain text; they are encrypted using **BCrypt** with salt rounds.
* Every request is verified via `AuthTokenFilter` extracting `Authorization: Bearer <token>`.
* Method-level authorization (`@PreAuthorize("hasRole('SELLER')")`) prevents unauthorized actions.

### 3. Why are calculations performed on the backend?
* Client-side pricing or cart calculations can be tampered with in browser developer tools. In AgriFresh, prices, stock availability, subtotals, and delivery fees are calculated inside `CartServiceImpl.java` and `OrderServiceImpl.java` using verified database values.

### 4. How does inventory concurrency work?
* When an order is placed, `OrderServiceImpl` validates that requested quantities are $\le$ `stockQuantity`. Upon confirmation, quantities are decremented. If an order is cancelled, stock is restored.

---

### Project Developed for Academic Demonstration & Viva Presentation
🌱 **AgriFresh – Farm Fresh Harvest, Delivered With Care.**
