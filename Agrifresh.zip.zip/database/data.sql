-- =======================================================
-- AgriFresh - Agriculture Product Delivery System
-- Sample Seed Data (MySQL)
-- Note: Passwords are encrypted with BCrypt
-- admin123 -> $2a$10$w6yJ78D7oJqgP8kFz9E6.. (use DataInitializer for auto-hashing)
-- =======================================================

USE agrifresh_db;

-- Insert Categories
INSERT INTO categories (id, name, description, image_url) VALUES
(1, 'Vegetables', 'Farm-fresh crunchy vegetables grown naturally and harvested daily.', 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80'),
(2, 'Fruits', 'Naturally sweetened, juicy seasonal and tropical farm fruits.', 'https://images.unsplash.com/photo-1619566636858-adf3ef46400b?auto=format&fit=crop&w=600&q=80'),
(3, 'Grains', 'Whole grains, basmati rice, wheat and traditional millets.', 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&w=600&q=80'),
(4, 'Pulses', 'Unpolished lentils, chickpeas, and protein-packed organic dals.', 'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80'),
(5, 'Dairy Products', 'Fresh A2 cow milk, artisanal paneer, churned butter and ghee.', 'https://images.unsplash.com/photo-1550583724-b2692b85b150?auto=format&fit=crop&w=600&q=80'),
(6, 'Organic Products', '100% Certified chemical-free, pesticide-free harvest and greens.', 'https://images.unsplash.com/photo-1610348725531-843dff563e2c?auto=format&fit=crop&w=600&q=80'),
(7, 'Seeds', 'High-germination vegetable, flower and crop seeds for farming.', 'https://images.unsplash.com/photo-1516253593875-bd7ba052fbc5?auto=format&fit=crop&w=600&q=80'),
(8, 'Spices', 'Aromatic whole and ground spices straight from coastal plantations.', 'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=600&q=80'),
(9, 'Honey', 'Raw, unprocessed pure forest honey collected directly by beekeepers.', 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=600&q=80'),
(10, 'Other Farm Products', 'Cold-pressed oils, jaggery, compost, and natural agro essentials.', 'https://images.unsplash.com/photo-1471193945509-9ad0617afabf?auto=format&fit=crop&w=600&q=80')
ON DUPLICATE KEY UPDATE name=VALUES(name);
