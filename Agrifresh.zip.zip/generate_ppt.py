import os
import sys
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN

def build_presentation():
    output_dir = os.path.join(os.path.dirname(__file__), "ppt")
    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, "AgriFresh_Project_Documentation.pptx")

    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    blank_layout = prs.slide_layouts[6]

    # Professional Theme Color Palette (AgriFresh Green & Slate)
    PRIMARY_GREEN = RGBColor(21, 128, 61)    # #15803D (Emerald 700)
    DARK_FOREST   = RGBColor(5, 46, 22)      # #052E16 (Deep Forest Green)
    DARK_NAVY     = RGBColor(15, 23, 42)     # #0F172A (Slate 900)
    ACCENT_AMBER  = RGBColor(217, 119, 6)    # #D97706 (Harvest Amber)
    LIGHT_BG      = RGBColor(248, 250, 252)  # #F8FAFC (Slate 50)
    CARD_BG       = RGBColor(255, 255, 255)  # White
    CARD_BORDER   = RGBColor(226, 232, 240)  # #E2E8F0 (Slate 200)
    GREEN_BORDER  = RGBColor(187, 247, 208)  # #BBF7D0 (Green 200)
    TEXT_MAIN     = RGBColor(15, 23, 42)     # #0F172A
    TEXT_MUTED    = RGBColor(100, 116, 139)  # #64748B
    WHITE         = RGBColor(255, 255, 255)
    SUCCESS_GREEN = RGBColor(34, 197, 94)    # #22C55E

    def add_header(slide, title_text, category_text="AGRIFRESH • ENGINEERING DOCUMENTATION & CAPSTONE DEFENSE"):
        top_bar = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(13.333), Inches(1.15))
        top_bar.fill.solid()
        top_bar.fill.fore_color.rgb = DARK_FOREST
        top_bar.line.color.rgb = DARK_FOREST

        accent_stripe = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(1.15), Inches(13.333), Inches(0.06))
        accent_stripe.fill.solid()
        accent_stripe.fill.fore_color.rgb = PRIMARY_GREEN
        accent_stripe.line.color.rgb = PRIMARY_GREEN

        cat_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.12), Inches(11.5), Inches(0.3))
        cat_tf = cat_box.text_frame
        cat_tf.word_wrap = True
        p_cat = cat_tf.paragraphs[0]
        p_cat.text = category_text.upper()
        p_cat.font.size = Pt(10)
        p_cat.font.bold = True
        p_cat.font.color.rgb = ACCENT_AMBER

        title_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.38), Inches(11.8), Inches(0.68))
        tf = title_box.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        p.text = title_text
        p.font.size = Pt(21)
        p.font.bold = True
        p.font.color.rgb = WHITE

    def add_card(slide, left, top, width, height, bg_color=CARD_BG, border_color=CARD_BORDER):
        shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(left), Inches(top), Inches(width), Inches(height))
        shape.fill.solid()
        shape.fill.fore_color.rgb = bg_color
        if border_color:
            shape.line.color.rgb = border_color
            shape.line.width = Pt(1.5)
        else:
            shape.line.fill.background()
        return shape

    def set_notes(slide, notes_text):
        slide.notes_slide.notes_text_frame.text = notes_text.strip()

    # =========================================================================
    # SLIDE 1: TITLE SLIDE
    # =========================================================================
    s1 = prs.slides.add_slide(blank_layout)
    bg1 = s1.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(13.333), Inches(7.5))
    bg1.fill.solid()
    bg1.fill.fore_color.rgb = DARK_FOREST
    bg1.line.color.rgb = DARK_FOREST

    dec_bar = s1.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.8), Inches(1.2), Inches(0.12), Inches(4.0))
    dec_bar.fill.solid()
    dec_bar.fill.fore_color.rgb = PRIMARY_GREEN
    dec_bar.line.color.rgb = PRIMARY_GREEN

    t_box = s1.shapes.add_textbox(Inches(1.2), Inches(1.15), Inches(11.2), Inches(4.2))
    tf1 = t_box.text_frame
    tf1.word_wrap = True

    p0 = tf1.paragraphs[0]
    p0.text = "FULL-STACK CAPSTONE ENGINEERING PROJECT • VIVA PRESENTATION"
    p0.font.size = Pt(13)
    p0.font.bold = True
    p0.font.color.rgb = ACCENT_AMBER

    p1 = tf1.add_paragraph()
    p1.text = "AgriFresh: Direct Farm-to-Consumer Agriculture E-Commerce & Supply Chain System"
    p1.font.size = Pt(28)
    p1.font.bold = True
    p1.font.color.rgb = WHITE

    p2 = tf1.add_paragraph()
    p2.text = "A Layered Micro-Enterprise Architecture with Multi-Role Access Control (RBAC), Real-Time 5-Stage Dispatch Tracking, and Concurrency-Safe Inventory Management"
    p2.font.size = Pt(15)
    p2.font.color.rgb = RGBColor(209, 250, 229)

    p3 = tf1.add_paragraph()
    p3.text = "\nCore Stack: Java 17 / 21 | Spring Boot 3.2.5 | Spring Security 6 + JWT | MySQL 8.0 | Hibernate ORM | HTML5, CSS3 & Modern JS (ES6+)"
    p3.font.size = Pt(13)
    p3.font.color.rgb = RGBColor(167, 243, 208)

    # Links card
    add_card(s1, 1.2, 5.3, 11.0, 1.5, bg_color=RGBColor(6, 78, 59), border_color=PRIMARY_GREEN)
    l_box = s1.shapes.add_textbox(Inches(1.4), Inches(5.4), Inches(10.6), Inches(1.3))
    ltf = l_box.text_frame
    ltf.word_wrap = True

    lp1 = ltf.paragraphs[0]
    lp1.text = "🔗 Live Deployment & Verification Links:"
    lp1.font.size = Pt(12)
    lp1.font.bold = True
    lp1.font.color.rgb = WHITE

    lp2 = ltf.add_paragraph()
    lp2.text = "• Local Web Application: "
    lp2.font.size = Pt(11)
    lp2.font.color.rgb = RGBColor(209, 250, 229)
    r1 = lp2.add_run()
    r1.text = "http://localhost:8080"
    r1.font.bold = True
    r1.font.color.rgb = RGBColor(56, 189, 248)
    r1.hyperlink.address = "http://localhost:8080"

    r_p = lp2.add_run()
    r_p.text = "   |   • Products API: "
    r_p.font.color.rgb = RGBColor(209, 250, 229)
    r2 = lp2.add_run()
    r2.text = "http://localhost:8080/api/products"
    r2.font.bold = True
    r2.font.color.rgb = RGBColor(56, 189, 248)
    r2.hyperlink.address = "http://localhost:8080/api/products"

    r_p2 = lp2.add_run()
    r_p2.text = "   |   • Database DDL: "
    r_p2.font.color.rgb = RGBColor(209, 250, 229)
    r3 = lp2.add_run()
    r3.text = "schema.sql"
    r3.font.bold = True
    r3.font.color.rgb = RGBColor(56, 189, 248)

    set_notes(s1, """SPEAKER NOTES:
Respected examiners, guide, and panel members, good morning.
Today, I am proud to present our final year full-stack engineering capstone project: AgriFresh — a direct farm-to-consumer agricultural product delivery and supply chain management system.
In traditional agricultural supply chains, farmers lose over 40% of their rightful margins to intermediate brokers, while household consumers pay elevated prices for produce that has lost freshness in lengthy transit.
AgriFresh bridges this divide through an enterprise-grade decoupled architecture built with Java 17/21, Spring Boot 3.2.5, Spring Security 6 with stateless JWT authentication, and a normalized MySQL 8 relational persistence model.
It features live 5-stage delivery tracking, server-side dynamic cart validation, atomic inventory updates, and complete multi-role portals for Customers, Farmers, and System Administrators.""")

    # =========================================================================
    # SLIDE 2: PROBLEM STATEMENT & INDUSTRY MOTIVATION
    # =========================================================================
    s2 = prs.slides.add_slide(blank_layout)
    add_header(s2, "Problem Statement & Agricultural Supply Chain Challenges")

    # Left Card: Farmer Crisis
    add_card(s2, 0.8, 1.45, 5.7, 5.6, border_color=RGBColor(254, 202, 202))
    b2_l = s2.shapes.add_textbox(Inches(1.0), Inches(1.55), Inches(5.3), Inches(5.3))
    tf2_l = b2_l.text_frame
    tf2_l.word_wrap = True
    p = tf2_l.paragraphs[0]
    p.text = "Farmer & Producer Inefficiencies"
    p.font.size = Pt(16)
    p.font.bold = True
    p.font.color.rgb = RGBColor(185, 28, 28)

    f_points = [
        ("Middlemen Exploitation:", "Farmers receive barely 20–30% of consumer retail value due to 4 to 6 intermediary commission agents (dalals/aggregators)."),
        ("Post-Harvest Produce Waste:", "Delayed logistics and lack of direct demand forecasting cause 30–40% loss of highly perishable fruits and greens."),
        ("No Transparent Pricing Power:", "Smallholder farmers are forced into distress sales during harvest peaks without direct market price visibility."),
        ("Delayed Cash Realization:", "Payment cycles in traditional mandis take weeks, stranding farmer working capital for seeds and fertilizers.")
    ]
    for h, b in f_points:
        p_item = tf2_l.add_paragraph()
        p_item.text = f"• {h} "
        p_item.font.size = Pt(11)
        p_item.font.bold = True
        p_item.font.color.rgb = TEXT_MAIN
        r = p_item.add_run()
        r.text = b
        r.font.bold = False
        r.font.color.rgb = TEXT_MUTED

    # Right Card: Consumer & Platform Pain Points
    add_card(s2, 6.8, 1.45, 5.7, 5.6, border_color=RGBColor(254, 215, 170))
    b2_r = s2.shapes.add_textbox(Inches(7.0), Inches(1.55), Inches(5.3), Inches(5.3))
    tf2_r = b2_r.text_frame
    tf2_r.word_wrap = True
    p_r = tf2_r.paragraphs[0]
    p_r.text = "Consumer & Logistics Deficiencies"
    p_r.font.size = Pt(16)
    p_r.font.bold = True
    p_r.font.color.rgb = ACCENT_AMBER

    c_points = [
        ("Loss of Freshness & Nutrients:", "Vegetables spend 48 to 72 hours traveling through mandis and wholesale depots before reaching retail counters."),
        ("Zero Origin Traceability:", "Consumers have no verified information on which farm cultivated the crops, cultivation methods, or harvesting date."),
        ("Inflated Retail Prices:", "Consumers pay 3x higher markups to cover middleman commissions and transit spoilage overheads."),
        ("Opaque Delivery Status:", "Standard grocery delivery apps lack granular farm-dispatch visibility, leading to unpredictable delivery expectations.")
    ]
    for h, b in c_points:
        p_item = tf2_r.add_paragraph()
        p_item.text = f"• {h} "
        p_item.font.size = Pt(11)
        p_item.font.bold = True
        p_item.font.color.rgb = TEXT_MAIN
        r = p_item.add_run()
        r.text = b
        r.font.bold = False
        r.font.color.rgb = TEXT_MUTED

    set_notes(s2, """SPEAKER NOTES:
On Slide 2, we highlight the core socio-economic and supply chain motivation.
Traditional agriculture is plagued by asymmetric information and redundant layers of brokers. In developing markets, up to 40% of fresh vegetables perish before reaching city tables, while the actual cultivators earn a fraction of the final selling price.
On the consumer side, families pay premium prices for produce harvested days prior, with zero transparency regarding farm origin or organic practices.
AgriFresh addresses both sides of this equation by establishing a direct, digitally unified farm-to-door delivery channel.""")

    # =========================================================================
    # SLIDE 3: PROPOSED SOLUTION & CORE VALUE PROPOSITION
    # =========================================================================
    s3 = prs.slides.add_slide(blank_layout)
    add_header(s3, "AgriFresh Solution: Farm-to-Table Marketplace Model")

    # 3 Horizontal Strategy Cards
    cards_data = [
        ("🌾 Direct Farmer Listing", "Eliminates intermediaries. Farmers register, list produce with harvest origin, set prices, and retain 90%+ margins.", PRIMARY_GREEN, GREEN_BORDER),
        ("🛡 Concurrency-Safe Stock", "Real-time stock checks inside Cart & Order service prevent overselling during flash purchases with ACID rollback.", ACCENT_AMBER, RGBColor(254, 215, 170)),
        ("🚚 5-Stage Live Tracking", "End-to-end transparent dispatch pipeline from 'Order Placed' to 'Delivered' with real-time UI progression.", RGBColor(37, 99, 235), RGBColor(191, 219, 254))
    ]

    col_w = 3.65
    gap = 0.35
    for i, (title, desc, col_hdr, col_brd) in enumerate(cards_data):
        c_left = 0.8 + i * (col_w + gap)
        add_card(s3, c_left, 1.45, col_w, 3.2, border_color=col_brd)
        tb = s3.shapes.add_textbox(Inches(c_left + 0.15), Inches(1.6), Inches(col_w - 0.3), Inches(2.9))
        tf = tb.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        p.text = title
        p.font.size = Pt(15)
        p.font.bold = True
        p.font.color.rgb = col_hdr

        p_desc = tf.add_paragraph()
        p_desc.text = f"\n{desc}"
        p_desc.font.size = Pt(11)
        p_desc.font.color.rgb = TEXT_MAIN

    # Bottom Full-Width Feature Breakdown Card
    add_card(s3, 0.8, 4.9, 11.7, 2.15, bg_color=LIGHT_BG, border_color=GREEN_BORDER)
    tb_bot = s3.shapes.add_textbox(Inches(1.0), Inches(5.0), Inches(11.3), Inches(1.9))
    tf_bot = tb_bot.text_frame
    tf_bot.word_wrap = True

    p = tf_bot.paragraphs[0]
    p.text = "⭐ Key Architectural Differentiators & Highlights:"
    p.font.size = Pt(13)
    p.font.bold = True
    p.font.color.rgb = DARK_FOREST

    sub_features = [
        ("Role-Based Access Control (RBAC):", "Segregated environments for Customers, Farmers, and Super-Admins with Spring Security 6 & BCrypt."),
        ("Dynamic Delivery Subsidy:", "Automated server-side threshold engine: Free delivery on orders over ₹500, nominal ₹40 charge otherwise."),
        ("Multi-Channel Simulated Checkout:", "Supports simulated UPI QR scanner, Credit/Debit cards, Net Banking, and Cash on Delivery (COD)."),
        ("Farm Credential Verification:", "Farmers register with verifiable farm locations, crop types, and contact credentials displayed to consumers.")
    ]
    for h, b in sub_features:
        p_f = tf_bot.add_paragraph()
        p_f.text = f"✔ {h} "
        p_f.font.size = Pt(10.5)
        p_f.font.bold = True
        p_f.font.color.rgb = PRIMARY_GREEN
        r = p_f.add_run()
        r.text = b
        r.font.bold = False
        r.font.color.rgb = TEXT_MAIN

    set_notes(s3, """SPEAKER NOTES:
Slide 3 outlines our proposed solution. AgriFresh is not merely an online brochure — it is a transactional platform engineered to solve core logistics, inventory, and trust challenges.
First, farmers have direct autonomy over their harvest catalog and pricing.
Second, inventory safety is enforced at the database and service layer — no customer can place an order exceeding available real-time harvest stock.
Third, consumers experience complete visibility through our 5-stage tracking timeline, simulated multi-modal payments, and transparent farm origin credentials.""")

    # =========================================================================
    # SLIDE 4: SYSTEM ARCHITECTURE & 3-TIER ENTERPRISE STACK
    # =========================================================================
    s4 = prs.slides.add_slide(blank_layout)
    add_header(s4, "Layered Enterprise System Architecture")

    # 4 Architecture Tier Cards
    tiers = [
        ("1. Presentation Tier (Client)", "HTML5 / CSS3 / ES6 JavaScript", [
            "Pure responsive design with custom natural green theme.",
            "Stateless Fetch API communication with backend REST endpoints.",
            "JWT token preservation in browser localStorage.",
            "Instant UI updates for dynamic carts, live timelines, and mod-panels."
        ], RGBColor(37, 99, 235), RGBColor(191, 219, 254)),

        ("2. API & Security Tier", "Spring Web MVC & Spring Security 6", [
            "RESTful JSON controllers (@RestController) with standardized response wrappers.",
            "AuthTokenFilter interceptor inspecting Bearer JWT headers on every request.",
            "BCrypt password hashing algorithm (strength 10 rounds).",
            "Role authorization rules: ROLE_CUSTOMER, ROLE_SELLER, ROLE_ADMIN."
        ], PRIMARY_GREEN, GREEN_BORDER),

        ("3. Business Logic Tier", "Spring Boot 3.2 Services & DTOs", [
            "Service layer encapsulating transactional business rules (@Transactional).",
            "CartService & OrderService validating stock and atomic inventory decrement.",
            "DataInitializer auto-seeding demo categories, users, and farm listings.",
            "Custom exception handling with @RestControllerAdvice returning unified errors."
        ], ACCENT_AMBER, RGBColor(254, 215, 170)),

        ("4. Persistence Tier", "Spring Data JPA & MySQL 8.0", [
            "Hibernate ORM mapping Java entities to normalized 3NF relational tables.",
            "HikariCP connection pool ensuring high-throughput connection reuse.",
            "Cascading integrity and foreign keys ensuring consistency across tables.",
            "Optional zero-config H2 in-memory fallback for offline demonstrations."
        ], RGBColor(147, 51, 234), RGBColor(233, 213, 255))
    ]

    tier_h = 1.3
    tier_gap = 0.12
    for i, (title, tech, bullets, hdr_col, brd_col) in enumerate(tiers):
        t_top = 1.45 + i * (tier_h + tier_gap)
        add_card(s4, 0.8, t_top, 11.7, tier_h, border_color=brd_col)

        # Left title box
        tbox_l = s4.shapes.add_textbox(Inches(0.95), Inches(t_top + 0.1), Inches(3.2), Inches(tier_h - 0.2))
        tf_l = tbox_l.text_frame
        tf_l.word_wrap = True
        p_t = tf_l.paragraphs[0]
        p_t.text = title
        p_t.font.size = Pt(13)
        p_t.font.bold = True
        p_t.font.color.rgb = hdr_col
        p_sub = tf_l.add_paragraph()
        p_sub.text = tech
        p_sub.font.size = Pt(10)
        p_sub.font.bold = True
        p_sub.font.color.rgb = TEXT_MUTED

        # Right bullets box
        tbox_r = s4.shapes.add_textbox(Inches(4.3), Inches(t_top + 0.08), Inches(8.0), Inches(tier_h - 0.16))
        tf_r = tbox_r.text_frame
        tf_r.word_wrap = True
        for b_idx, b_text in enumerate(bullets):
            p_b = tf_r.paragraphs[0] if b_idx == 0 else tf_r.add_paragraph()
            p_b.text = f"• {b_text}"
            p_b.font.size = Pt(10)
            p_b.font.color.rgb = TEXT_MAIN

    set_notes(s4, """SPEAKER NOTES:
Slide 4 details our layered enterprise architecture.
We followed industry best practices by enforcing strict separation of concerns across 4 tiers:
1. Presentation Tier: Responsive Vanilla HTML5/CSS3 and modern ES6 JavaScript. No heavyweight framework overhead, maximizing browser compatibility and page load speed.
2. Security & Controller Tier: Spring Web MVC handles REST routing, while Spring Security 6 provides stateless JWT verification via custom filters.
3. Service Tier: Contains transactional business rules. Stock decrement, fee calculation, and order validation are all executed server-side.
4. Persistence Tier: Spring Data JPA and Hibernate communicate with MySQL 8.0, utilizing connection pooling and referential integrity.""")

    # =========================================================================
    # SLIDE 5: DATABASE DESIGN & SCHEMA ARCHITECTURE
    # =========================================================================
    s5 = prs.slides.add_slide(blank_layout)
    add_header(s5, "Relational Database Schema & Entity Relationships (MySQL 8)")

    # Left: Entities Table / Summary
    add_card(s5, 0.8, 1.45, 6.2, 5.6, border_color=GREEN_BORDER)
    tb_db = s5.shapes.add_textbox(Inches(1.0), Inches(1.55), Inches(5.8), Inches(5.4))
    tf_db = tb_db.text_frame
    tf_db.word_wrap = True

    p = tf_db.paragraphs[0]
    p.text = "Normalized 3NF Relational Structure"
    p.font.size = Pt(15)
    p.font.bold = True
    p.font.color.rgb = PRIMARY_GREEN

    db_entities = [
        ("users", "id, email, password, full_name, phone, address, role (CUSTOMER, SELLER, ADMIN), is_active, created_at"),
        ("sellers", "id, user_id (FK), farm_name, farm_location, farm_size_acres, description, created_at"),
        ("categories", "id, name, slug, description, image_url, is_active"),
        ("products", "id, seller_id (FK), category_id (FK), name, description, price, unit (kg, bunch, litre), stock_qty, image_url, is_active"),
        ("carts & cart_items", "cart_id, user_id (FK), product_id (FK), quantity, added_at"),
        ("orders & order_items", "id, order_number, user_id, total_amount, delivery_fee, status, shipping_address; order_id, product_id, qty, price"),
        ("payments", "id, order_id (FK), payment_method (COD, UPI, CARD, NET_BANKING), transaction_ref, status (SUCCESS), amount, paid_at"),
        ("reviews", "id, product_id (FK), user_id (FK), rating (1-5), comment, created_at")
    ]

    for tbl, cols in db_entities:
        p_tbl = tf_db.add_paragraph()
        p_tbl.text = f"📁 {tbl}: "
        p_tbl.font.size = Pt(10.5)
        p_tbl.font.bold = True
        p_tbl.font.color.rgb = DARK_FOREST
        r = p_tbl.add_run()
        r.text = cols
        r.font.bold = False
        r.font.size = Pt(9.5)
        r.font.color.rgb = TEXT_MUTED

    # Right: Data Integrity & Relationship Guarantees
    add_card(s5, 7.3, 1.45, 5.2, 5.6, border_color=CARD_BORDER)
    tb_rel = s5.shapes.add_textbox(Inches(7.5), Inches(1.55), Inches(4.8), Inches(5.4))
    tf_rel = tb_rel.text_frame
    tf_rel.word_wrap = True

    p_r = tf_rel.paragraphs[0]
    p_r.text = "Relational Guarantees & ER Design"
    p_r.font.size = Pt(15)
    p_r.font.bold = True
    p_r.font.color.rgb = DARK_NAVY

    er_points = [
        ("1-to-1: User ➔ Seller", "Farmers inherit core authentication details from users while storing dedicated farm land credentials in sellers."),
        ("1-to-Many: Category ➔ Products", "Normalized taxonomy allows products to be classified into Grains, Vegetables, Dairy, Fruits, Honey, and Spices."),
        ("1-to-Many: Farmer ➔ Products", "Products link directly to seller_id, enabling granular farmer dashboard inventory queries."),
        ("Atomic Orders Snapshot", "order_items copies unit price at checkout time, preventing future product price changes from altering historical invoices."),
        ("ACID Transaction Isolation", "Order placement executes under @Transactional to ensure payments, orders, and stock updates commit together or roll back entirely.")
    ]
    for h, b in er_points:
        p_item = tf_rel.add_paragraph()
        p_item.text = f"• {h}: "
        p_item.font.size = Pt(10.5)
        p_item.font.bold = True
        p_item.font.color.rgb = PRIMARY_GREEN
        r = p_item.add_run()
        r.text = b
        r.font.bold = False
        r.font.size = Pt(10)
        r.font.color.rgb = TEXT_MAIN

    set_notes(s5, """SPEAKER NOTES:
Slide 5 explores our MySQL 8 relational schema.
The database schema consists of 8 core tables designed in Third Normal Form (3NF).
A crucial engineering design decision here is the price snapshotting in `order_items`. Notice that when an order is created, the current price is copied into the `order_items` record. This guarantees that if a farmer subsequently updates the produce price from ₹40 to ₹50, historical invoices remain immutable and accurate.
Additionally, user authentication is unified in `users`, while farm-specific metadata like farm location and land acreage is segregated in `sellers` with a 1-to-1 foreign key constraint.""")

    # =========================================================================
    # SLIDE 6: MULTI-ROLE ACCESS CONTROL (RBAC) & PERMISSIONS
    # =========================================================================
    s6 = prs.slides.add_slide(blank_layout)
    add_header(s6, "Role-Based Access Control (RBAC) & Actor Portals")

    roles = [
        ("👤 CUSTOMER PORTAL", "Consumer Experience", [
            "Browse catalog, filter categories, search produce.",
            "Add to cart with real-time stock ceiling validation.",
            "Select delivery address & simulated payment mode.",
            "Track 5-stage live order progress with visual timeline.",
            "Write product ratings & post reviews.",
            "Order history, cancellation, and invoice generation."
        ], RGBColor(37, 99, 235), RGBColor(191, 219, 254)),

        ("🚜 FARMER / SELLER PORTAL", "Agricultural Producer Center", [
            "Dedicated farm profile registration with location details.",
            "Add produce with units (kg, litre, bunch, packet, dozen).",
            "Real-time inventory stock management & price updates.",
            "Order fulfillment dashboard: view received customer orders.",
            "Advance order status: CONFIRMED ➔ PACKED ➔ OUT_FOR_DELIVERY.",
            "Revenue analytics & pending delivery tracking."
        ], PRIMARY_GREEN, GREEN_BORDER),

        ("⚡ SYSTEM ADMINISTRATOR", "Platform Moderation & Governance", [
            "System-wide overview of all registered users and farmers.",
            "One-click user account activation / deactivation.",
            "Category management: create, edit, or disable crop categories.",
            "Full order audit log across all platform transactions.",
            "System KPI dashboard: platform-wide revenue & active listings.",
            "Secured via @PreAuthorize(\"hasRole('ADMIN')\")."
        ], ACCENT_AMBER, RGBColor(254, 215, 170))
    ]

    r_w = 3.65
    r_gap = 0.35
    for i, (rtitle, rsub, rbullets, rhdr, rbrd) in enumerate(roles):
        r_left = 0.8 + i * (r_w + r_gap)
        add_card(s6, r_left, 1.45, r_w, 5.6, border_color=rbrd)

        tb_r = s6.shapes.add_textbox(Inches(r_left + 0.15), Inches(1.55), Inches(r_w - 0.3), Inches(5.4))
        tf_r = tb_r.text_frame
        tf_r.word_wrap = True

        p_t = tf_r.paragraphs[0]
        p_t.text = rtitle
        p_t.font.size = Pt(14)
        p_t.font.bold = True
        p_t.font.color.rgb = rhdr

        p_s = tf_r.add_paragraph()
        p_s.text = rsub
        p_s.font.size = Pt(10.5)
        p_s.font.bold = True
        p_s.font.color.rgb = TEXT_MUTED

        tf_r.add_paragraph() # Spacer

        for b in rbullets:
            p_b = tf_r.add_paragraph()
            p_b.text = f"✔ {b}"
            p_b.font.size = Pt(10)
            p_b.font.color.rgb = TEXT_MAIN

    set_notes(s6, """SPEAKER NOTES:
Slide 6 illustrates our Role-Based Access Control model. AgriFresh implements three segregated roles:
1. Customers: Browse items, manage their cart, execute simulated checkout, and monitor live tracking.
2. Farmers: Have an authenticated command center to manage their active crop inventory, adjust pricing according to harvest conditions, and advance incoming order statuses.
3. Administrators: Moderate the platform by monitoring platform-wide metrics, managing product categories, and toggling user accounts active or inactive to prevent abuse.
Access control is enforced both on the client via UI route guards and on the server via Spring Security's `@PreAuthorize` annotations.""")

    # =========================================================================
    # SLIDE 7: CORE WORKFLOW 1 – CONSUMER JOURNEY & SMART CART ENGINE
    # =========================================================================
    s7 = prs.slides.add_slide(blank_layout)
    add_header(s7, "Consumer Journey: Smart Cart Engine & Inventory Guard")

    # Left: Step-by-Step Flow
    add_card(s7, 0.8, 1.45, 6.0, 5.6, border_color=GREEN_BORDER)
    tb_c1 = s7.shapes.add_textbox(Inches(1.0), Inches(1.55), Inches(5.6), Inches(5.4))
    tf_c1 = tb_c1.text_frame
    tf_c1.word_wrap = True

    p = tf_c1.paragraphs[0]
    p.text = "End-to-End Consumer Ordering Flow"
    p.font.size = Pt(15)
    p.font.bold = True
    p.font.color.rgb = PRIMARY_GREEN

    steps_c1 = [
        ("1. Harvest Discovery:", "User browses produce catalog with multi-criteria filtering by category, harvest origin, and price ascending/descending."),
        ("2. Real-Time Stock Validation:", "When customer adds item to cart, backend validates 'requestedQty <= availableStock'. Excessive quantities are blocked with descriptive errors."),
        ("3. Dynamic Delivery Fee Engine:", "Backend recalculates cart subtotal. If subtotal >= ₹500, delivery fee is set to ₹0.00 (Free Delivery). Otherwise, ₹40.00 is appended."),
        ("4. Seamless Checkout:", "User confirms pre-filled delivery address from their profile or specifies alternate delivery details."),
        ("5. Instant Invoice Generation:", "Upon payment confirmation, a unique order tracking code (e.g., ORD-20261007-XXXX) is issued with itemized pricing.")
    ]
    for s_title, s_desc in steps_c1:
        p_s = tf_c1.add_paragraph()
        p_s.text = f"{s_title} "
        p_s.font.size = Pt(11)
        p_s.font.bold = True
        p_s.font.color.rgb = DARK_FOREST
        r = p_s.add_run()
        r.text = s_desc
        r.font.bold = False
        r.font.size = Pt(10)
        r.font.color.rgb = TEXT_MAIN

    # Right: Technical Security & Concurrency Card
    add_card(s7, 7.1, 1.45, 5.4, 5.6, border_color=CARD_BORDER)
    tb_c2 = s7.shapes.add_textbox(Inches(7.3), Inches(1.55), Inches(5.0), Inches(5.4))
    tf_c2 = tb_c2.text_frame
    tf_c2.word_wrap = True

    p_r = tf_c2.paragraphs[0]
    p_r.text = "Why Calculations Must Live on Backend"
    p_r.font.size = Pt(15)
    p_r.font.bold = True
    p_r.font.color.rgb = DARK_NAVY

    backend_reasons = [
        ("Tamper-Proof Financial Calculations:", "In naive web apps, client JavaScript computes totals which malicious users can tamper with in DevTools. In AgriFresh, prices and totals are fetched strictly from MySQL."),
        ("Atomic Stock Decrement:", "Inventory is decremented inside a database transaction during order placement. If two users order the last 5 kg of tomatoes simultaneously, only the first transaction succeeds."),
        ("Automated Stock Restoration on Cancel:", "If a customer cancels a placed order before dispatch, the backend automatically increments inventory back to the farmer's listing."),
        ("Zero Double-Dipping:", "Cart items reference current live stock to prevent purchasing items that went out of stock while sitting in cart.")
    ]
    for b_title, b_desc in backend_reasons:
        p_b = tf_c2.add_paragraph()
        p_b.text = f"🛡 {b_title} "
        p_b.font.size = Pt(10.5)
        p_b.font.bold = True
        p_b.font.color.rgb = PRIMARY_GREEN
        r = p_b.add_run()
        r.text = b_desc
        r.font.bold = False
        r.font.size = Pt(10)
        r.font.color.rgb = TEXT_MUTED

    set_notes(s7, """SPEAKER NOTES:
Slide 7 delves into the smart cart engine and consumer workflow.
An examiner often asks during project viva: 'Where are cart totals calculated?'
Our answer is unequivocal: All subtotal, delivery fee, and discount calculations are performed strictly on the backend within `CartServiceImpl` and `OrderServiceImpl`.
If an order's subtotal meets the ₹500 threshold, the server automatically waives the ₹40 delivery fee.
Furthermore, concurrency protection is implemented so that stock availability is checked at the exact moment of order checkout, preventing overselling.""")

    # =========================================================================
    # SLIDE 8: CORE WORKFLOW 2 – 5-STAGE REAL-TIME ORDER TRACKING
    # =========================================================================
    s8 = prs.slides.add_slide(blank_layout)
    add_header(s8, "5-Stage Real-Time Delivery Tracking & Status Pipeline")

    stages = [
        ("1. ORDER_PLACED", "Customer completes payment. Order ID assigned. Farmer notified of pending harvest dispatch.", PRIMARY_GREEN),
        ("2. CONFIRMED", "Farmer acknowledges order. Inventory verified and allocated from fresh harvest lot.", PRIMARY_GREEN),
        ("3. PACKED", "Harvest sorted, weighed, packaged in eco-friendly crates, labeled with customer shipping tag.", ACCENT_AMBER),
        ("4. OUT_FOR_DELIVERY", "Dispatched to local refrigerated delivery carrier. ETA calculated for customer doorstep.", RGBColor(37, 99, 235)),
        ("5. DELIVERED", "Handed over to customer. OTP/Signature verified. Farmer payout balance finalized.", RGBColor(22, 101, 52))
    ]

    s_w = 2.15
    s_gap = 0.24
    for i, (st_name, st_desc, st_col) in enumerate(stages):
        st_left = 0.8 + i * (s_w + s_gap)
        add_card(s8, st_left, 1.45, s_w, 3.4, border_color=st_col)
        tb_s = s8.shapes.add_textbox(Inches(st_left + 0.1), Inches(1.55), Inches(s_w - 0.2), Inches(3.2))
        tf_s = tb_s.text_frame
        tf_s.word_wrap = True

        p_s = tf_s.paragraphs[0]
        p_s.text = f"Stage {i+1}"
        p_s.font.size = Pt(12)
        p_s.font.bold = True
        p_s.font.color.rgb = st_col

        p_t = tf_s.add_paragraph()
        p_t.text = st_name
        p_t.font.size = Pt(11)
        p_t.font.bold = True
        p_t.font.color.rgb = DARK_NAVY

        p_d = tf_s.add_paragraph()
        p_d.text = f"\n{st_desc}"
        p_d.font.size = Pt(9.5)
        p_d.font.color.rgb = TEXT_MAIN

    # Bottom Timeline Architecture & UI Feedback
    add_card(s8, 0.8, 5.1, 11.7, 1.95, bg_color=LIGHT_BG, border_color=GREEN_BORDER)
    tb_pipe = s8.shapes.add_textbox(Inches(1.0), Inches(5.15), Inches(11.3), Inches(1.8))
    tf_pipe = tb_pipe.text_frame
    tf_pipe.word_wrap = True

    p = tf_pipe.paragraphs[0]
    p.text = "⚡ Real-Time Tracking Engine Architecture:"
    p.font.size = Pt(13)
    p.font.bold = True
    p.font.color.rgb = DARK_FOREST

    pipe_points = [
        ("Visual Timeline Animation:", "order-tracking.html features a CSS pulsing milestone bar. When status changes in MySQL, reloading or polling reflects the new stage immediately."),
        ("Fulfillment Governance:", "Only the designated seller or administrator has permissions to execute PATCH /api/seller/orders/{id}/status to transition stages."),
        ("Edge Case: Cancellation Handlers:", "If cancelled prior to PACKED stage, status updates to CANCELLED and stock is atomically refunded to inventory.")
    ]
    for h, b in pipe_points:
        p_p = tf_pipe.add_paragraph()
        p_p.text = f"• {h} "
        p_p.font.size = Pt(10)
        p_p.font.bold = True
        p_p.font.color.rgb = PRIMARY_GREEN
        r = p_p.add_run()
        r.text = b
        r.font.bold = False
        r.font.color.rgb = TEXT_MAIN

    set_notes(s8, """SPEAKER NOTES:
Slide 8 displays the 5-stage live delivery tracking pipeline.
Unlike black-box e-commerce systems, AgriFresh breaks down delivery into transparent agricultural milestones:
Order Placed, Confirmed, Packed, Out for Delivery, and Delivered.
In `order-tracking.html`, customers can enter their Order Number (such as `ORD-20261007-DEMO`) to see an animated graphical timeline with dynamic pulse highlights showing exactly which milestone the parcel has reached.
Sellers manage these transitions directly from `seller-orders.html` using a simple dropdown status action.""")

    # =========================================================================
    # SLIDE 9: CORE WORKFLOW 3 – SIMULATED MULTI-CHANNEL PAYMENT GATEWAY
    # =========================================================================
    s9 = prs.slides.add_slide(blank_layout)
    add_header(s9, "Simulated Multi-Channel Payment Gateway Architecture")

    pay_modes = [
        ("📱 UPI Payment (QR & VPA)", "Scan & Pay Simulation", [
            "Simulated dynamic QR code linked to order total amount.",
            "Instant Virtual Payment Address (VPA) verification.",
            "Interactive 'Verify & Pay' simulated authorization.",
            "Logs mock transaction reference (e.g., UPI-83920194)."
        ], PRIMARY_GREEN, GREEN_BORDER),

        ("💳 Credit / Debit Card", "Sandbox Card Processing", [
            "Card number, expiry date, and CVV formatting validation.",
            "Simulated 3D-Secure OTP authorization dialog.",
            "Guaranteed zero storage of sensitive CVV/card numbers.",
            "Issues instantaneous transaction confirmation token."
        ], RGBColor(37, 99, 235), RGBColor(191, 219, 254)),

        ("🏦 Net Banking & COD", "Traditional & Cash Modes", [
            "Support for major nationalized and private bank simulation.",
            "Cash on Delivery (COD) mode for rural and offline buyers.",
            "Automated payment status tagging: PENDING vs SUCCESS.",
            "Immediate invoice generation on order completion."
        ], ACCENT_AMBER, RGBColor(254, 215, 170))
    ]

    p_w = 3.65
    p_gap = 0.35
    for i, (mtitle, msub, mbullets, mhdr, mbrd) in enumerate(pay_modes):
        p_left = 0.8 + i * (p_w + p_gap)
        add_card(s9, p_left, 1.45, p_w, 5.6, border_color=mbrd)

        tb_m = s9.shapes.add_textbox(Inches(p_left + 0.15), Inches(1.55), Inches(p_w - 0.3), Inches(5.4))
        tf_m = tb_m.text_frame
        tf_m.word_wrap = True

        p_t = tf_m.paragraphs[0]
        p_t.text = mtitle
        p_t.font.size = Pt(14)
        p_t.font.bold = True
        p_t.font.color.rgb = mhdr

        p_s = tf_m.add_paragraph()
        p_s.text = msub
        p_s.font.size = Pt(10.5)
        p_s.font.bold = True
        p_s.font.color.rgb = TEXT_MUTED

        tf_m.add_paragraph()

        for b in mbullets:
            p_b = tf_m.add_paragraph()
            p_b.text = f"✔ {b}"
            p_b.font.size = Pt(10)
            p_b.font.color.rgb = TEXT_MAIN

    set_notes(s9, """SPEAKER NOTES:
Slide 9 showcases our simulated payment gateway.
For academic and evaluation convenience, we engineered a realistic mock payment gateway inside `payment.html` and `PaymentController.java`.
It supports:
1. UPI with a simulated QR code and VPA verification.
2. Credit/Debit Card sandbox approval.
3. Net Banking and Cash on Delivery.
Every payment transaction is stored in the `payments` table with its foreign key to the `orders` table, capturing amount, payment method, payment status, and a unique transaction reference ID.""")

    # =========================================================================
    # SLIDE 10: SECURITY ARCHITECTURE & STATELESS JWT AUTHENTICATION
    # =========================================================================
    s10 = prs.slides.add_slide(blank_layout)
    add_header(s10, "Security Architecture: Spring Security 6 & Stateless JWT")

    # Left: Security Pipeline Flow
    add_card(s10, 0.8, 1.45, 6.0, 5.6, border_color=GREEN_BORDER)
    tb_sec1 = s10.shapes.add_textbox(Inches(1.0), Inches(1.55), Inches(5.6), Inches(5.4))
    tf_sec1 = tb_sec1.text_frame
    tf_sec1.word_wrap = True

    p = tf_sec1.paragraphs[0]
    p.text = "JWT Authentication & Authorization Pipeline"
    p.font.size = Pt(15)
    p.font.bold = True
    p.font.color.rgb = PRIMARY_GREEN

    sec_steps = [
        ("1. User Credential Submission:", "Client submits email and password over HTTPS to /api/auth/login."),
        ("2. BCrypt Password Verification:", "UserDetailsServiceImpl retrieves user record. BCryptPasswordEncoder validates salt and hash without plain-text exposure."),
        ("3. Cryptographic JWT Generation:", "JwtUtils generates a digitally signed JSON Web Token using HMAC-SHA256 containing userId, email, and GrantedAuthorities."),
        ("4. Stateless Request Interception:", "AuthTokenFilter intercepts every subsequent HTTP call, parses the 'Authorization: Bearer <token>' header, and populates SecurityContextHolder."),
        ("5. Method-Level Access Check:", "@PreAuthorize annotations verify whether the principal has the requisite role before controller execution begins.")
    ]
    for s_title, s_desc in sec_steps:
        p_s = tf_sec1.add_paragraph()
        p_s.text = f"{s_title} "
        p_s.font.size = Pt(10.5)
        p_s.font.bold = True
        p_s.font.color.rgb = DARK_FOREST
        r = p_s.add_run()
        r.text = s_desc
        r.font.bold = False
        r.font.size = Pt(9.5)
        r.font.color.rgb = TEXT_MAIN

    # Right: Defense-in-Depth Protections
    add_card(s10, 7.1, 1.45, 5.4, 5.6, border_color=CARD_BORDER)
    tb_sec2 = s10.shapes.add_textbox(Inches(7.3), Inches(1.55), Inches(5.0), Inches(5.4))
    tf_sec2 = tb_sec2.text_frame
    tf_sec2.word_wrap = True

    p_r = tf_sec2.paragraphs[0]
    p_r.text = "Defense-in-Depth Mechanisms"
    p_r.font.size = Pt(15)
    p_r.font.bold = True
    p_r.font.color.rgb = DARK_NAVY

    defense_points = [
        ("Stateless Server Scaling:", "Because no HTTP session is stored in server RAM, the backend can be clustered horizontally across multiple nodes effortlessly."),
        ("SQL Injection Immunity:", "Spring Data JPA utilizes parameterized prepared statements, preventing malicious SQL injection attacks in all repository queries."),
        ("Cross-Site Scripting (XSS) Prevention:", "Input validation and structured JSON serialization prevent script injection across produce descriptions and reviews."),
        ("Role Privilege Isolation:", "A Customer cannot invoke /api/seller/* or /api/admin/* endpoints; any attempt results in an immediate HTTP 403 Forbidden.")
    ]
    for d_title, d_desc in defense_points:
        p_d = tf_sec2.add_paragraph()
        p_d.text = f"🔒 {d_title} "
        p_d.font.size = Pt(10.5)
        p_d.font.bold = True
        p_d.font.color.rgb = PRIMARY_GREEN
        r = p_d.add_run()
        r.text = d_desc
        r.font.bold = False
        r.font.size = Pt(10)
        r.font.color.rgb = TEXT_MUTED

    set_notes(s10, """SPEAKER NOTES:
Slide 10 details our security implementation.
In AgriFresh, we use Spring Security 6 combined with JSON Web Tokens (JWT).
When a user logs in, their password is verified against an encrypted BCrypt hash.
If valid, the server signs a JWT containing the user's ID, role, and expiration timestamp.
The frontend stores this token and sends it in the `Authorization: Bearer <token>` header of every API call.
`AuthTokenFilter` intercepts and verifies the signature before setting the authentication in Spring's SecurityContext.
This guarantees that server endpoints are completely protected without relying on sticky server sessions.""")

    # =========================================================================
    # SLIDE 11: VERIFICATION & TESTING MATRIX
    # =========================================================================
    s11 = prs.slides.add_slide(blank_layout)
    add_header(s11, "System Verification & Acceptance Testing Matrix")

    test_cases = [
        ("TC-01: Dual Role Registration", "Register as Farmer with Farm credentials", "Account created; redirected to seller-dashboard.html", "PASSED"),
        ("TC-02: Role Redirection", "Click quick-fill button & login as Seller", "Authenticated via JWT; lands on seller workspace", "PASSED"),
        ("TC-03: Stock Ceiling Validation", "Attempt ordering 151 kg when stock is 150 kg", "Blocked: 'Requested quantity exceeds available stock'", "PASSED"),
        ("TC-04: Free Delivery Threshold", "Cart total < ₹500 vs >= ₹500", "₹40 delivery fee waived when cart exceeds ₹500", "PASSED"),
        ("TC-05: Atomic Inventory Decrement", "Checkout order with 5 kg produce", "Stock decrements from 150 to 145 in MySQL", "PASSED"),
        ("TC-06: Live Delivery Tracking", "Search order ORD-20261007-DEMO", "5-step timeline highlights active CONFIRMED step", "PASSED"),
        ("TC-07: Farmer Status Progression", "Farmer updates order status to PACKED", "Saved in DB; customer tracking reflects PACKED", "PASSED"),
        ("TC-08: Order Cancellation Rollback", "Customer cancels un-dispatched order", "Status becomes CANCELLED; stock restored to inventory", "PASSED"),
        ("TC-09: Admin User Moderation", "Admin deactivates customer account", "User cannot login; receives 401 Unauthorized", "PASSED")
    ]

    row_h = 0.52
    for i, (t_id, t_step, t_res, t_stat) in enumerate(test_cases):
        r_top = 1.45 + i * (row_h + 0.08)
        add_card(s11, 0.8, r_top, 11.7, row_h, border_color=GREEN_BORDER)

        tb_row = s11.shapes.add_textbox(Inches(0.9), Inches(r_top + 0.05), Inches(11.5), Inches(row_h - 0.1))
        tf_row = tb_row.text_frame
        tf_row.word_wrap = True

        p = tf_row.paragraphs[0]
        p.text = f"{t_id}: "
        p.font.size = Pt(10)
        p.font.bold = True
        p.font.color.rgb = DARK_FOREST

        r_step = p.add_run()
        r_step.text = f"{t_step} ➔ "
        r_step.font.color.rgb = TEXT_MUTED

        r_res = p.add_run()
        r_res.text = f"{t_res} "
        r_res.font.color.rgb = TEXT_MAIN

        r_stat = p.add_run()
        r_stat.text = f"[{t_stat}]"
        r_stat.font.bold = True
        r_stat.font.color.rgb = PRIMARY_GREEN

    set_notes(s11, """SPEAKER NOTES:
Slide 11 provides our structured test execution matrix.
We formulated 9 comprehensive test cases covering authentication, inventory concurrency, pricing rules, delivery tracking, and administrative moderation.
For example, in Test Case 03, we verified that a customer cannot buy more items than are physically present in stock.
In Test Case 04, we verified the automated delivery fee waiver when cart values exceed ₹500.
And in Test Case 08, we verified the automated inventory rollback when an order is cancelled.
All test cases successfully passed during system evaluation.""")

    # =========================================================================
    # SLIDE 12: VIVA VOCE & TECHNICAL DEFENSE GUIDE
    # =========================================================================
    s12 = prs.slides.add_slide(blank_layout)
    add_header(s12, "Viva Voce & Technical Defense Q&A Guide")

    viva_qa = [
        ("Q1: How does AgriFresh prevent race conditions when two users buy the last stock item simultaneously?",
         "Answer: Concurrency is managed at the service and database layer inside an @Transactional boundary. When an order is placed, the service checks stock against available quantity in the database and updates it atomically. If available quantity falls below requested units, the transaction is rejected with a BadRequestException and changes are rolled back."),

        ("Q2: Why use JWT tokens instead of standard HttpSession cookies?",
         "Answer: JWT tokens enable completely stateless backend architecture. The server does not allocate session memory in RAM for thousands of concurrent users. Furthermore, stateless JWTs make the backend instantly ready for future native Android/iOS mobile apps without CORS cookie complexities."),

        ("Q3: Why are cart totals and delivery fees computed on the backend rather than in JavaScript?",
         "Answer: Security integrity. Client-side JavaScript running in the browser can be manipulated using Developer Tools or proxy tools. By enforcing calculation inside CartServiceImpl and OrderServiceImpl, the application ensures that prices and fee subsidies originate strictly from verified database records."),

        ("Q4: How are passwords secured in the database against data leaks?",
         "Answer: Passwords are encrypted using Spring Security's BCryptPasswordEncoder with salt rounds. BCrypt is a cryptographic one-way hashing function designed with a configurable work factor to be resilient against brute-force and dictionary attacks.")
    ]

    q_h = 1.3
    q_gap = 0.12
    for i, (q, a) in enumerate(viva_qa):
        q_top = 1.45 + i * (q_h + q_gap)
        add_card(s12, 0.8, q_top, 11.7, q_h, border_color=CARD_BORDER)

        tb_q = s12.shapes.add_textbox(Inches(1.0), Inches(q_top + 0.08), Inches(11.3), Inches(q_h - 0.16))
        tf_q = tb_q.text_frame
        tf_q.word_wrap = True

        p_q = tf_q.paragraphs[0]
        p_q.text = q
        p_q.font.size = Pt(11)
        p_q.font.bold = True
        p_q.font.color.rgb = DARK_FOREST

        p_a = tf_q.add_paragraph()
        p_a.text = a
        p_a.font.size = Pt(9.5)
        p_a.font.color.rgb = TEXT_MAIN

    set_notes(s12, """SPEAKER NOTES:
Slide 12 addresses the four most critical technical questions expected during our viva defense.
These questions focus on system concurrency, stateless authentication rationale, server-side data integrity vs client manipulation, and cryptographic security.
Having crisp, definitive architectural answers demonstrates deep engineering understanding beyond surface-level code implementation.""")

    # =========================================================================
    # SLIDE 13: FUTURE ENHANCEMENTS & LOGISTICS ROADMAP
    # =========================================================================
    s13 = prs.slides.add_slide(blank_layout)
    add_header(s13, "Future Scope & Technological Enhancements")

    future_features = [
        ("📡 IoT Cold-Chain Monitoring", "Hardware Integration", [
            "Integration of ESP32 and DHT22 temperature/humidity sensors inside delivery crates.",
            "Live transit telemetry streamed to cloud to ensure zero spoilage of perishables.",
            "Automatic quality flagging if transit temperature exceeds safe storage thresholds."
        ], RGBColor(37, 99, 235), RGBColor(191, 219, 254)),

        ("🤖 AI Predictive Crop Pricing", "Machine Learning Analytics", [
            "Machine learning regression model analyzing historical market data and seasonal yields.",
            "Dynamic price recommendations helping farmers price crops competitively without brokers.",
            "Demand forecasting helping farmers plan harvest schedules to minimize excess spoilage."
        ], PRIMARY_GREEN, GREEN_BORDER),

        ("⛓ Blockchain Harvest Provenance", "Distributed Ledger Trust", [
            "Hyperledger or Ethereum-based smart contracts logging seed sowing, pesticide use, and harvest date.",
            "QR code on produce packaging allowing consumers to scan and verify authentic organic farm origin."
        ], ACCENT_AMBER, RGBColor(254, 215, 170)),

        ("🗣 Voice-Assisted Vernacular UI", "Rural Farmer Inclusivity", [
            "Voice-to-text crop listing in regional Indian languages (Hindi, Marathi, Telugu, Tamil).",
            "Simplifies inventory stock updates for farmers who are less tech-savvy."
        ], RGBColor(147, 51, 234), RGBColor(233, 213, 255))
    ]

    fut_w = 2.7
    fut_gap = 0.28
    for i, (ftitle, fsub, fbullets, fhdr, fbrd) in enumerate(future_features):
        f_left = 0.8 + i * (fut_w + fut_gap)
        add_card(s13, f_left, 1.45, fut_w, 5.6, border_color=fbrd)

        tb_f = s13.shapes.add_textbox(Inches(f_left + 0.12), Inches(1.55), Inches(fut_w - 0.24), Inches(5.4))
        tf_f = tb_f.text_frame
        tf_f.word_wrap = True

        p_t = tf_f.paragraphs[0]
        p_t.text = ftitle
        p_t.font.size = Pt(13)
        p_t.font.bold = True
        p_t.font.color.rgb = fhdr

        p_s = tf_f.add_paragraph()
        p_s.text = fsub
        p_s.font.size = Pt(10)
        p_s.font.bold = True
        p_s.font.color.rgb = TEXT_MUTED

        tf_f.add_paragraph()

        for b in fbullets:
            p_b = tf_f.add_paragraph()
            p_b.text = f"• {b}"
            p_b.font.size = Pt(9.5)
            p_b.font.color.rgb = TEXT_MAIN

    set_notes(s13, """SPEAKER NOTES:
Slide 13 outlines future engineering enhancements for AgriFresh.
While our current system delivers an enterprise-grade full-stack foundation, future extensions include:
1. IoT-enabled cold chain telemetry to monitor crate temperatures in real time.
2. AI-assisted crop pricing algorithms to suggest fair market prices based on seasonal demand.
3. Blockchain provenance logging so consumers can scan a QR code to verify organic certification.
4. Multilingual voice assistance to make the application seamlessly accessible to rural farmers.""")

    # =========================================================================
    # SLIDE 14: CONCLUSION & PROJECT SUMMARY
    # =========================================================================
    s14 = prs.slides.add_slide(blank_layout)
    bg14 = s14.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(13.333), Inches(7.5))
    bg14.fill.solid()
    bg14.fill.fore_color.rgb = DARK_FOREST
    bg14.line.color.rgb = DARK_FOREST

    t_box14 = s14.shapes.add_textbox(Inches(1.2), Inches(1.0), Inches(11.0), Inches(5.5))
    tf14 = t_box14.text_frame
    tf14.word_wrap = True

    p0 = tf14.paragraphs[0]
    p0.text = "PROJECT CONCLUSION & SUMMARY"
    p0.font.size = Pt(14)
    p0.font.bold = True
    p0.font.color.rgb = ACCENT_AMBER

    p1 = tf14.add_paragraph()
    p1.text = "AgriFresh: Delivering Fresh Harvest, Empowering Cultivators."
    p1.font.size = Pt(26)
    p1.font.bold = True
    p1.font.color.rgb = WHITE

    concl_points = [
        "Elimination of Middlemen: Directly connects local farmers with urban consumers, significantly boosting farm revenue while lowering consumer costs.",
        "Production-Grade Security: Robust Spring Security 6 stateless JWT architecture and BCrypt password encryption safeguarding all platform roles.",
        "Reliable Real-Time Operations: Concurrency-safe inventory management, server-side pricing rules, and a 5-stage live delivery tracking timeline.",
        "Complete Full-Stack Implementation: 85+ Java classes, 17 responsive web pages, normalized MySQL 8 database schema, and comprehensive test suite."
    ]
    for cp in concl_points:
        p_c = tf14.add_paragraph()
        p_c.text = f"\n✔ {cp}"
        p_c.font.size = Pt(13)
        p_c.font.color.rgb = RGBColor(209, 250, 229)

    p_end = tf14.add_paragraph()
    p_end.text = "\nThank you! We welcome questions from the evaluation committee."
    p_end.font.size = Pt(15)
    p_end.font.bold = True
    p_end.font.color.rgb = WHITE

    set_notes(s14, """SPEAKER NOTES:
In conclusion, AgriFresh successfully fulfills all engineering objectives set out for our capstone review.
We have demonstrated a working, full-stack enterprise web application that directly connects agricultural producers with household consumers, enforces bulletproof inventory and security rules, and provides transparent delivery tracking.
Thank you for your time and guidance. We are now open for questions and code demonstration.""")

    prs.save(output_path)
    print(f"Presentation successfully created at: {output_path}")

if __name__ == "__main__":
    build_presentation()
