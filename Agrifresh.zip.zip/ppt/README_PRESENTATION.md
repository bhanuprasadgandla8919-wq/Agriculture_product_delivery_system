# 🌾 AgriFresh — Presentation & System Documentation

The complete 14-slide Widescreen (16:9) PowerPoint presentation file has been generated:

📁 **File:** [`AgriFresh_Project_Documentation.pptx`](file:///c:/Users/vaish/.gemini/antigravity/scratch/agrifresh/ppt/AgriFresh_Project_Documentation.pptx)  
📄 **Generator Script:** [`generate_ppt.py`](file:///c:/Users/vaish/.gemini/antigravity/scratch/agrifresh/generate_ppt.py)  
🌐 **Live Application:** [http://localhost:8080/](http://localhost:8080/)  

---

### Slide Deck Structure (14 Slides)
1. **Title & Executive Overview** (Project details, live link, tech stack)
2. **Problem Statement & Agricultural Supply Chain Inefficiencies** (Middlemen loss, post-harvest perishability)
3. **Proposed Solution & Core Value Proposition** (Direct marketplace, inventory guard)
4. **Layered Enterprise System Architecture** (Presentation, Security/API, Service, Persistence)
5. **Relational Database Schema & ER Design** (3NF normalized tables, price snapshotting)
6. **Multi-Role Access Control (RBAC)** (Customer, Farmer/Seller, Administrator)
7. **Consumer Journey & Smart Cart Engine** (Stock ceiling checks, free delivery threshold)
8. **5-Stage Real-Time Delivery Tracking** (Placed ➔ Confirmed ➔ Packed ➔ Out for Delivery ➔ Delivered)
9. **Simulated Multi-Channel Payment Gateway** (UPI QR/VPA, Credit/Debit card sandbox, Net Banking, COD)
10. **Security Architecture & Stateless JWT** (Spring Security 6, BCrypt, AuthTokenFilter)
11. **System Verification & Acceptance Testing Matrix** (9 passed test cases)
12. **Viva Voce & Technical Defense Q&A** (4 core technical defense answers)
13. **Future Scope & Technological Enhancements** (IoT cold-chain telemetry, AI price guidance, Blockchain)
14. **Project Conclusion & Summary** (Achievements and deliverables)

---

### Quick Commands
To re-generate or modify the presentation deck:
```powershell
cd c:\Users\vaish\.gemini\antigravity\scratch\agrifresh
python generate_ppt.py
```
