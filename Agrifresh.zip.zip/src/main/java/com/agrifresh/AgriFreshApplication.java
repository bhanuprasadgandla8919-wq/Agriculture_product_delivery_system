package com.agrifresh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgriFreshApplication {

    public static void main(String[] args) {
        SpringApplication.run(AgriFreshApplication.class, args);
        System.out.println("=================================================");
        System.out.println(" AgriFresh Web Application Started Successfully! ");
        System.out.println(" URL: http://localhost:8080/                      ");
        System.out.println(" API: http://localhost:8080/api/products          ");
        System.out.println("=================================================");
    }
}
