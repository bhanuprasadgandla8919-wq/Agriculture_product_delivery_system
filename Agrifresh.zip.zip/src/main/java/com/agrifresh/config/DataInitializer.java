package com.agrifresh.config;

import com.agrifresh.entity.*;
import com.agrifresh.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Component
public class DataInitializer implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(DataInitializer.class);

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private SellerRepository sellerRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private ReviewRepository reviewRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        logger.info("Initializing and verifying AgriFresh seed data...");
        seedDatabase();
        logger.info("AgriFresh database seed verification completed successfully.");
    }

    private Category getOrCreateCategory(String name, String description, String imageUrl) {
        return categoryRepository.findByNameIgnoreCase(name)
                .orElseGet(() -> categoryRepository.save(new Category(name, description, imageUrl)));
    }

    private User getOrCreateUser(String name, String email, String phone, String rawPassword, Role role, String address) {
        return userRepository.findByEmail(email)
                .orElseGet(() -> userRepository.save(new User(name, email, phone, passwordEncoder.encode(rawPassword), role, address)));
    }

    private Seller getOrCreateSeller(User user, String farmName, String farmLocation) {
        return sellerRepository.findByUserId(user.getId())
                .orElseGet(() -> sellerRepository.save(new Seller(user, farmName, farmLocation)));
    }

    private void seedDatabase() {
        // 1. Seed Categories
        Category veg = getOrCreateCategory(
                "Vegetables",
                "Farm-fresh crunchy vegetables grown naturally and harvested daily.",
                "https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80"
        );

        Category fruits = getOrCreateCategory(
                "Fruits",
                "Naturally sweetened, juicy seasonal and tropical farm fruits.",
                "https://images.unsplash.com/photo-1619566636858-adf3ef46400b?auto=format&fit=crop&w=600&q=80"
        );

        Category grains = getOrCreateCategory(
                "Grains",
                "Whole grains, basmati rice, wheat and traditional millets.",
                "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&w=600&q=80"
        );

        Category pulses = getOrCreateCategory(
                "Pulses",
                "Unpolished lentils, chickpeas, and protein-packed organic dals.",
                "https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80"
        );

        Category dairy = getOrCreateCategory(
                "Dairy Products",
                "Fresh A2 cow milk, artisanal paneer, churned butter and ghee.",
                "https://images.unsplash.com/photo-1550583724-b2692b85b150?auto=format&fit=crop&w=600&q=80"
        );

        Category organic = getOrCreateCategory(
                "Organic Products",
                "100% Certified chemical-free, pesticide-free harvest and greens.",
                "https://images.unsplash.com/photo-1610348725531-843dff563e2c?auto=format&fit=crop&w=600&q=80"
        );

        Category seeds = getOrCreateCategory(
                "Seeds",
                "High-germination vegetable, flower and crop seeds for farming.",
                "https://images.unsplash.com/photo-1516253593875-bd7ba052fbc5?auto=format&fit=crop&w=600&q=80"
        );

        Category spices = getOrCreateCategory(
                "Spices",
                "Aromatic whole and ground spices straight from coastal plantations.",
                "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=600&q=80"
        );

        Category honey = getOrCreateCategory(
                "Honey",
                "Raw, unprocessed pure forest honey collected directly by beekeepers.",
                "https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=600&q=80"
        );

        Category other = getOrCreateCategory(
                "Other Farm Products",
                "Cold-pressed oils, jaggery, compost, and natural agro essentials.",
                "https://images.unsplash.com/photo-1471193945509-9ad0617afabf?auto=format&fit=crop&w=600&q=80"
        );

        // 2. Seed Users & Sellers
        User admin = getOrCreateUser(
                "System Administrator",
                "admin@agrifresh.com",
                "+91 9876543210",
                "admin123",
                Role.ROLE_ADMIN,
                "AgriFresh HQ, Cyber City, Bangalore, Karnataka"
        );

        User sellerUser1 = getOrCreateUser(
                "Ramesh Patil",
                "ramesh@farm.com",
                "+91 9822012345",
                "seller123",
                Role.ROLE_SELLER,
                "Farm No. 42, Dindori Road, Nashik, Maharashtra - 422004"
        );
        Seller seller1 = getOrCreateSeller(sellerUser1, "Green Valley Organic Farm", "Dindori Valley, Nashik, Maharashtra");

        User sellerUser2 = getOrCreateUser(
                "Sita Devi",
                "sita@farm.com",
                "+91 9765432109",
                "seller123",
                Role.ROLE_SELLER,
                "Plot 18, Saswad Highway, Pune, Maharashtra - 412301"
        );
        Seller seller2 = getOrCreateSeller(sellerUser2, "Sunrise Agro Farms", "Saswad Ridge, Pune, Maharashtra");

        User customer1 = getOrCreateUser(
                "Rahul Sharma",
                "rahul@gmail.com",
                "+91 9811223344",
                "customer123",
                Role.ROLE_CUSTOMER,
                "Flat 402, Sunshine Heights, Baner Road, Pune, Maharashtra - 411045"
        );
        if (cartRepository.findByUserId(customer1.getId()).isEmpty()) {
            cartRepository.save(new Cart(customer1));
        }

        User customer2 = getOrCreateUser(
                "Priya Verma",
                "priya@gmail.com",
                "+91 9922334455",
                "customer123",
                Role.ROLE_CUSTOMER,
                "Villa 12, Palm Meadows, Whitefield, Bangalore, Karnataka - 560066"
        );
        if (cartRepository.findByUserId(customer2.getId()).isEmpty()) {
            cartRepository.save(new Cart(customer2));
        }

        // 3. Seed Products if count is low
        if (productRepository.count() <= 1) {
            List<Product> products = new ArrayList<>();

            Product p1 = new Product(
                seller1, veg, "Organic Red Tomatoes",
                "Juicy, vine-ripened organic red tomatoes with rich flavor, grown without synthetic pesticides.",
                45.0, 150, "kg",
                "https://images.unsplash.com/photo-1592924357228-91a4daadcfea?auto=format&fit=crop&w=600&q=80"
        );
        products.add(p1);

        Product p2 = new Product(
                seller1, veg, "Crisp Green Capsicum",
                "Farm-fresh crisp bell peppers, ideal for stir-fries, salads, and healthy cooking.",
                60.0, 80, "kg",
                "https://images.unsplash.com/photo-1563565375-f3fdfdbefa83?auto=format&fit=crop&w=600&q=80"
        );
        products.add(p2);

        Product p3 = new Product(
                seller2, veg, "Farm Fresh Spinach (Palak)",
                "Tender organic green spinach bunches harvested early morning. Packed with natural iron and folate.",
                25.0, 100, "bunch",
                "https://images.unsplash.com/photo-1576045057995-568f588f82fb?auto=format&fit=crop&w=600&q=80"
        );
        products.add(p3);

        Product p4 = new Product(
                seller1, fruits, "Shimla Royal Delicious Apples",
                "Sweet, crunchy high-altitude mountain apples freshly handpicked from Himachal orchards.",
                180.0, 75, "kg",
                "https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?auto=format&fit=crop&w=600&q=80"
        );
        products.add(p4);

        Product p5 = new Product(
                seller2, fruits, "Nagpur Sweet Oranges",
                "Juicy, vitamin-C rich sweet oranges harvested directly from Vidarbha farms.",
                80.0, 120, "kg",
                "https://images.unsplash.com/photo-1611080626919-7cf5a9dbab5b?auto=format&fit=crop&w=600&q=80"
        );
        products.add(p5);

        Product p6 = new Product(
                seller1, grains, "Traditional Basmati Rice (Aged 2 Years)",
                "Extra long grain aromatic basmati rice aged naturally for superior fluffy texture and royal aroma.",
                140.0, 200, "kg",
                "https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80"
        );
        products.add(p6);

        Product p7 = new Product(
                seller2, pulses, "Organic Unpolished Toor Dal",
                "Nutritious, high-protein yellow pigeon peas without any chemical polishing or artificial coloring.",
                160.0, 90, "kg",
                "https://images.unsplash.com/photo-1515543237350-b3eea1ec8082?auto=format&fit=crop&w=600&q=80"
        );
        products.add(p7);

        Product p8 = new Product(
                seller1, dairy, "Pure A2 Gir Cow Desi Ghee",
                "Traditional Bilona method churned golden ghee made from pasture-raised Gir cow whole milk.",
                750.0, 45, "litre",
                "https://images.unsplash.com/photo-1631451095765-2c91616fc9e6?auto=format&fit=crop&w=600&q=80"
        );
        products.add(p8);

        Product p9 = new Product(
                seller2, honey, "Raw Wildflower Forest Honey",
                "Unheated, unpasteurized 100% natural pure honey retaining all natural enzymes and pollen notes.",
                380.0, 60, "kg",
                "https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=600&q=80"
        );
        products.add(p9);

        Product p10 = new Product(
                seller1, spices, "Wayanad Black Pepper",
                "Bold, pungent single-origin sun-dried black peppercorns from Kerala high ranges.",
                220.0, 50, "packet",
                "https://images.unsplash.com/photo-1509358271058-acd22cc93898?auto=format&fit=crop&w=600&q=80"
        );
        products.add(p10);

        Product p11 = new Product(
                seller2, organic, "Cold-Pressed Mustard Oil",
                "Traditional wooden kolhu cold-pressed pure mustard oil with authentic aroma and natural antioxidants.",
                210.0, 70, "litre",
                "https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?auto=format&fit=crop&w=600&q=80"
        );
        products.add(p11);

        Product p12 = new Product(
                seller1, seeds, "Heirloom Tomato & Chilly Seed Kit",
                "Certified organic open-pollinated kitchen garden starter kit with 95%+ germination rate.",
                120.0, 100, "packet",
                "https://images.unsplash.com/photo-1516253593875-bd7ba052fbc5?auto=format&fit=crop&w=600&q=80"
        );
        products.add(p12);

        productRepository.saveAll(products);

        // 4. Seed Reviews
        reviewRepository.save(new Review(p1, customer1, 5, "The tomatoes were incredibly fresh and aromatic, just like handpicked from my grandpa's farm!"));
        reviewRepository.save(new Review(p1, customer2, 4, "Great texture, no blemishes, fast delivery. Will order again."));
        reviewRepository.save(new Review(p8, customer1, 5, "Exceptional aroma and authentic golden grain structure. True A2 bilona ghee!"));
        reviewRepository.save(new Review(p9, customer2, 5, "Real pure raw honey! The crystallized pollen at the bottom confirms authentic quality."));

        // 5. Seed a Sample Order for Customer 1 to demonstrate Order Tracking
        Order sampleOrder = new Order();
        sampleOrder.setOrderNumber("ORD-20261007-DEMO");
        sampleOrder.setCustomer(customer1);
        sampleOrder.setCustomerName("Rahul Sharma");
        sampleOrder.setCustomerPhone("+91 9811223344");
        sampleOrder.setDeliveryAddress("Flat 402, Sunshine Heights, Baner Road");
        sampleOrder.setCity("Pune");
        sampleOrder.setState("Maharashtra");
        sampleOrder.setPincode("411045");
        sampleOrder.setSubtotal(840.0);
        sampleOrder.setDeliveryCharge(0.0);
        sampleOrder.setTotalAmount(840.0);
        sampleOrder.setOrderStatus(OrderStatus.CONFIRMED);
        sampleOrder.setOrderDate(LocalDateTime.now().minusHours(4));
        sampleOrder.setExpectedDeliveryDate(LocalDateTime.now().plusDays(2));

        OrderItem oi1 = new OrderItem(sampleOrder, p1, seller1, 2, 45.0, 90.0);
        OrderItem oi2 = new OrderItem(sampleOrder, p8, seller1, 1, 750.0, 750.0);
        sampleOrder.getItems().add(oi1);
        sampleOrder.getItems().add(oi2);

        Order savedOrder = orderRepository.save(sampleOrder);

        Payment payment = new Payment(savedOrder, PaymentMethod.UPI, PaymentStatus.SUCCESS, "UPI-DEMO-98231", 840.0);
        paymentRepository.save(payment);
        savedOrder.setPayment(payment);
        orderRepository.save(savedOrder);
        }
    }
}
