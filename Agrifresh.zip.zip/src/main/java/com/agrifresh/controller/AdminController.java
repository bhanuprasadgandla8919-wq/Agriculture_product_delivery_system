package com.agrifresh.controller;

import com.agrifresh.dto.ApiResponse;
import com.agrifresh.dto.DashboardStatsDto;
import com.agrifresh.dto.OrderDto;
import com.agrifresh.dto.UserDto;
import com.agrifresh.service.OrderService;
import com.agrifresh.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    @Autowired
    private UserService userService;

    @Autowired
    private OrderService orderService;

    @GetMapping("/users")
    public ResponseEntity<ApiResponse<List<UserDto>>> getAllUsers() {
        List<UserDto> users = userService.getAllUsers();
        return ResponseEntity.ok(ApiResponse.ok("Users retrieved successfully", users));
    }

    @PutMapping("/users/{id}/status")
    public ResponseEntity<ApiResponse<UserDto>> toggleUserStatus(@PathVariable Long id) {
        UserDto updated = userService.toggleUserStatus(id);
        return ResponseEntity.ok(ApiResponse.ok("User status updated successfully", updated));
    }

    @GetMapping("/sellers")
    public ResponseEntity<ApiResponse<List<UserDto>>> getAllSellers() {
        List<UserDto> sellers = userService.getAllSellers();
        return ResponseEntity.ok(ApiResponse.ok("Sellers retrieved successfully", sellers));
    }

    @GetMapping("/orders")
    public ResponseEntity<ApiResponse<List<OrderDto>>> getAllOrders() {
        List<OrderDto> orders = orderService.getAllOrders();
        return ResponseEntity.ok(ApiResponse.ok("All orders retrieved successfully", orders));
    }

    @GetMapping("/dashboard")
    public ResponseEntity<ApiResponse<DashboardStatsDto>> getAdminDashboard() {
        DashboardStatsDto stats = userService.getAdminDashboardStats();
        return ResponseEntity.ok(ApiResponse.ok("Admin dashboard stats retrieved", stats));
    }
}
