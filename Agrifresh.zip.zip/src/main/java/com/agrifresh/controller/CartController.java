package com.agrifresh.controller;

import com.agrifresh.dto.ApiResponse;
import com.agrifresh.dto.CartDto;
import com.agrifresh.dto.CartItemRequest;
import com.agrifresh.service.CartService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/cart")
@PreAuthorize("hasAnyRole('CUSTOMER', 'ADMIN')")
public class CartController {

    @Autowired
    private CartService cartService;

    @GetMapping
    public ResponseEntity<ApiResponse<CartDto>> getCart(@AuthenticationPrincipal UserDetails userDetails) {
        CartDto cart = cartService.getCart(userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.ok("Cart retrieved successfully", cart));
    }

    @PostMapping("/items")
    public ResponseEntity<ApiResponse<CartDto>> addItemToCart(
            @Valid @RequestBody CartItemRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        CartDto cart = cartService.addItemToCart(request, userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.ok("Item added to cart successfully", cart));
    }

    @PutMapping("/items/{id}")
    public ResponseEntity<ApiResponse<CartDto>> updateCartItemQuantity(
            @PathVariable Long id,
            @RequestBody Map<String, Integer> payload,
            @AuthenticationPrincipal UserDetails userDetails) {
        Integer quantity = payload.get("quantity");
        if (quantity == null) {
            quantity = 1;
        }
        CartDto cart = cartService.updateCartItemQuantity(id, quantity, userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.ok("Cart updated successfully", cart));
    }

    @DeleteMapping("/items/{id}")
    public ResponseEntity<ApiResponse<CartDto>> removeCartItem(
            @PathVariable Long id,
            @AuthenticationPrincipal UserDetails userDetails) {
        CartDto cart = cartService.removeCartItem(id, userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.ok("Item removed from cart", cart));
    }

    @DeleteMapping("/clear")
    public ResponseEntity<ApiResponse<Void>> clearCart(@AuthenticationPrincipal UserDetails userDetails) {
        cartService.clearCart(userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.ok("Cart cleared successfully", null));
    }
}
