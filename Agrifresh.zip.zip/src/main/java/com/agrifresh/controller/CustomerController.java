package com.agrifresh.controller;

import com.agrifresh.dto.ApiResponse;
import com.agrifresh.dto.DashboardStatsDto;
import com.agrifresh.dto.OrderDto;
import com.agrifresh.dto.ProfileUpdateRequest;
import com.agrifresh.dto.UserDto;
import com.agrifresh.service.OrderService;
import com.agrifresh.service.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/customer")
@PreAuthorize("hasAnyRole('CUSTOMER', 'ADMIN')")
public class CustomerController {

    @Autowired
    private UserService userService;

    @Autowired
    private OrderService orderService;

    @GetMapping("/profile")
    public ResponseEntity<ApiResponse<UserDto>> getCustomerProfile(
            @AuthenticationPrincipal UserDetails userDetails) {
        UserDto profile = userService.getUserProfile(userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.ok("Customer profile fetched", profile));
    }

    @PutMapping("/profile")
    public ResponseEntity<ApiResponse<UserDto>> updateCustomerProfile(
            @Valid @RequestBody ProfileUpdateRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        UserDto updated = userService.updateUserProfile(userDetails.getUsername(), request);
        return ResponseEntity.ok(ApiResponse.ok("Profile updated successfully", updated));
    }

    @GetMapping("/orders")
    public ResponseEntity<ApiResponse<List<OrderDto>>> getCustomerOrders(
            @AuthenticationPrincipal UserDetails userDetails) {
        List<OrderDto> orders = orderService.getCustomerOrders(userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.ok("Customer orders fetched", orders));
    }

    @GetMapping("/dashboard")
    public ResponseEntity<ApiResponse<DashboardStatsDto>> getCustomerDashboard(
            @AuthenticationPrincipal UserDetails userDetails) {
        DashboardStatsDto stats = userService.getCustomerDashboardStats(userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.ok("Customer dashboard stats fetched", stats));
    }
}
