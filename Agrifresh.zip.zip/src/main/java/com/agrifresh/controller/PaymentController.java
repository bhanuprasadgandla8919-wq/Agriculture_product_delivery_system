package com.agrifresh.controller;

import com.agrifresh.dto.ApiResponse;
import com.agrifresh.dto.PaymentDto;
import com.agrifresh.dto.PaymentRequest;
import com.agrifresh.service.PaymentService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    @PostMapping
    public ResponseEntity<ApiResponse<PaymentDto>> processPayment(
            @Valid @RequestBody PaymentRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        PaymentDto payment = paymentService.processPayment(request, userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.ok("Payment processed successfully!", payment));
    }

    @GetMapping("/{orderId}")
    public ResponseEntity<ApiResponse<PaymentDto>> getPaymentByOrderId(
            @PathVariable Long orderId,
            @AuthenticationPrincipal UserDetails userDetails) {
        PaymentDto payment = paymentService.getPaymentByOrderId(orderId, userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.ok("Payment details fetched successfully", payment));
    }
}
