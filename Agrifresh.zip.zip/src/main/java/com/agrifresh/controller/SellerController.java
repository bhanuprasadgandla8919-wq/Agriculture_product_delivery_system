package com.agrifresh.controller;

import com.agrifresh.dto.ApiResponse;
import com.agrifresh.dto.DashboardStatsDto;
import com.agrifresh.dto.OrderDto;
import com.agrifresh.dto.ProductDto;
import com.agrifresh.service.OrderService;
import com.agrifresh.service.ProductService;
import com.agrifresh.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/seller")
@PreAuthorize("hasAnyRole('SELLER', 'ADMIN')")
public class SellerController {

    @Autowired
    private ProductService productService;

    @Autowired
    private OrderService orderService;

    @Autowired
    private UserService userService;

    @GetMapping("/products")
    public ResponseEntity<ApiResponse<List<ProductDto>>> getSellerProducts(
            @AuthenticationPrincipal UserDetails userDetails) {
        List<ProductDto> products = productService.getProductsBySellerEmail(userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.ok("Seller products fetched successfully", products));
    }

    @GetMapping("/orders")
    public ResponseEntity<ApiResponse<List<OrderDto>>> getSellerOrders(
            @AuthenticationPrincipal UserDetails userDetails) {
        List<OrderDto> orders = orderService.getSellerOrders(userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.ok("Seller orders fetched successfully", orders));
    }

    @GetMapping("/dashboard")
    public ResponseEntity<ApiResponse<DashboardStatsDto>> getSellerDashboard(
            @AuthenticationPrincipal UserDetails userDetails) {
        DashboardStatsDto stats = userService.getSellerDashboardStats(userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.ok("Seller dashboard stats fetched successfully", stats));
    }
}
