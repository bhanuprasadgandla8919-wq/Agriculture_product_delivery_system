package com.agrifresh.entity;

public enum OrderStatus {
    ORDER_PLACED,
    CONFIRMED,
    PACKED,
    OUT_FOR_DELIVERY,
    DELIVERED,
    CANCELLED
}
