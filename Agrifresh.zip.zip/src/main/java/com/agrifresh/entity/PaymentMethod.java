package com.agrifresh.entity;

public enum PaymentMethod {
    CASH_ON_DELIVERY,
    UPI,
    CREDIT_DEBIT_CARD,
    NET_BANKING
}
