package com.agrifresh.entity;

public enum Role {
    ROLE_CUSTOMER,
    ROLE_SELLER,
    ROLE_ADMIN
}
