package com.agrifresh.repository;

import com.agrifresh.entity.Cart;
import com.agrifresh.entity.CartItem;
import com.agrifresh.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CartItemRepository extends JpaRepository<CartItem, Long> {
    Optional<CartItem> findByCartAndProduct(Cart cart, Product product);
    List<CartItem> findByCartId(Long cartId);
    void deleteByCart(Cart cart);
}
