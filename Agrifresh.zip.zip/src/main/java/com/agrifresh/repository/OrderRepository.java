package com.agrifresh.repository;

import com.agrifresh.entity.Order;
import com.agrifresh.entity.OrderStatus;
import com.agrifresh.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {

    Optional<Order> findByOrderNumber(String orderNumber);

    List<Order> findByCustomerOrderByOrderDateDesc(User customer);

    List<Order> findByCustomerEmailOrderByOrderDateDesc(String email);

    List<Order> findAllByOrderByOrderDateDesc();

    long countByOrderStatus(OrderStatus orderStatus);

    @Query("SELECT DISTINCT o FROM Order o JOIN o.items item WHERE item.seller.id = :sellerId ORDER BY o.orderDate DESC")
    List<Order> findOrdersBySellerId(@Param("sellerId") Long sellerId);

    @Query("SELECT DISTINCT o FROM Order o JOIN o.items item WHERE item.seller.user.email = :email ORDER BY o.orderDate DESC")
    List<Order> findOrdersBySellerEmail(@Param("email") String email);

    @Query("SELECT COUNT(DISTINCT o) FROM Order o JOIN o.items item WHERE item.seller.id = :sellerId")
    long countOrdersBySellerId(@Param("sellerId") Long sellerId);

    @Query("SELECT COUNT(DISTINCT o) FROM Order o JOIN o.items item WHERE item.seller.id = :sellerId AND o.orderStatus = :status")
    long countOrdersBySellerIdAndStatus(@Param("sellerId") Long sellerId, @Param("status") OrderStatus status);

    @Query("SELECT COALESCE(SUM(item.subtotal), 0.0) FROM OrderItem item WHERE item.seller.id = :sellerId AND item.order.orderStatus != 'CANCELLED'")
    Double calculateSellerRevenue(@Param("sellerId") Long sellerId);

    @Query("SELECT COALESCE(SUM(o.totalAmount), 0.0) FROM Order o WHERE o.orderStatus != 'CANCELLED'")
    Double calculateTotalSystemRevenue();
}
