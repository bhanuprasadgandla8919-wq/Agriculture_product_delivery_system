package com.agrifresh.repository;

import com.agrifresh.entity.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, Long> {
    Optional<Payment> findByOrderId(Long orderId);
    Optional<Payment> findByOrderOrderNumber(String orderNumber);
    Optional<Payment> findByTransactionId(String transactionId);
}
