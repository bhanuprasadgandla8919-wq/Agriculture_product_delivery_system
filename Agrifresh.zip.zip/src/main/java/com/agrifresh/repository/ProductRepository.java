package com.agrifresh.repository;

import com.agrifresh.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {

    List<Product> findByAvailableTrue();

    List<Product> findByCategoryIdAndAvailableTrue(Long categoryId);

    List<Product> findBySellerId(Long sellerId);

    List<Product> findBySellerUserEmail(String email);

    long countBySellerId(Long sellerId);

    @Query("SELECT p FROM Product p WHERE " +
           "(:keyword IS NULL OR LOWER(p.name) LIKE LOWER(CONCAT('%', :keyword, '%')) OR LOWER(p.description) LIKE LOWER(CONCAT('%', :keyword, '%'))) AND " +
           "(:categoryId IS NULL OR p.category.id = :categoryId) AND " +
           "(:minPrice IS NULL OR p.price >= :minPrice) AND " +
           "(:maxPrice IS NULL OR p.price <= :maxPrice) AND " +
           "(:sellerId IS NULL OR p.seller.id = :sellerId) AND " +
           "(:availableOnly IS NULL OR :availableOnly = false OR (p.available = true AND p.stockQuantity > 0))")
    List<Product> searchAndFilterProducts(
            @Param("keyword") String keyword,
            @Param("categoryId") Long categoryId,
            @Param("minPrice") Double minPrice,
            @Param("maxPrice") Double maxPrice,
            @Param("sellerId") Long sellerId,
            @Param("availableOnly") Boolean availableOnly
    );
}
