package com.agrifresh.repository;

import com.agrifresh.entity.Seller;
import com.agrifresh.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface SellerRepository extends JpaRepository<Seller, Long> {
    Optional<Seller> findByUser(User user);
    Optional<Seller> findByUserId(Long userId);
    Optional<Seller> findByUserEmail(String email);
}
