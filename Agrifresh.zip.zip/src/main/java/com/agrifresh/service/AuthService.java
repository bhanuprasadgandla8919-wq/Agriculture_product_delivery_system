package com.agrifresh.service;

import com.agrifresh.dto.AuthRequest;
import com.agrifresh.dto.AuthResponse;
import com.agrifresh.dto.RegisterRequest;

public interface AuthService {
    AuthResponse register(RegisterRequest request);
    AuthResponse login(AuthRequest request);
}
