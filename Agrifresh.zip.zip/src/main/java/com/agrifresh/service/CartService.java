package com.agrifresh.service;

import com.agrifresh.dto.CartDto;
import com.agrifresh.dto.CartItemRequest;

public interface CartService {
    CartDto getCart(String userEmail);
    CartDto addItemToCart(CartItemRequest request, String userEmail);
    CartDto updateCartItemQuantity(Long cartItemId, Integer quantity, String userEmail);
    CartDto removeCartItem(Long cartItemId, String userEmail);
    void clearCart(String userEmail);
}
