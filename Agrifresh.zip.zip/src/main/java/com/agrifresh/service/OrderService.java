package com.agrifresh.service;

import com.agrifresh.dto.OrderDto;
import com.agrifresh.dto.OrderRequest;
import com.agrifresh.entity.OrderStatus;

import java.util.List;

public interface OrderService {
    OrderDto createOrder(OrderRequest request, String customerEmail);
    OrderDto getOrderById(Long orderId, String userEmail);
    OrderDto getOrderByOrderNumber(String orderNumber, String userEmail);
    List<OrderDto> getCustomerOrders(String customerEmail);
    List<OrderDto> getSellerOrders(String sellerEmail);
    List<OrderDto> getAllOrders();
    OrderDto updateOrderStatus(Long orderId, OrderStatus status, String userEmail);
    OrderDto cancelOrder(Long orderId, String userEmail);
}
