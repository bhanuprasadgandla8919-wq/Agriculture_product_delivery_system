package com.agrifresh.service;

import com.agrifresh.dto.PaymentDto;
import com.agrifresh.dto.PaymentRequest;

public interface PaymentService {
    PaymentDto processPayment(PaymentRequest request, String userEmail);
    PaymentDto getPaymentByOrderId(Long orderId, String userEmail);
}
