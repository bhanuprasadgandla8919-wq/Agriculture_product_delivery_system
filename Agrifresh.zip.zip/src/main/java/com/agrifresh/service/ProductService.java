package com.agrifresh.service;

import com.agrifresh.dto.ProductDto;
import com.agrifresh.dto.ProductRequest;

import java.util.List;

public interface ProductService {
    List<ProductDto> getAllProducts();
    ProductDto getProductById(Long id);
    List<ProductDto> searchAndFilterProducts(String keyword, Long categoryId, Double minPrice,
                                            Double maxPrice, Long sellerId, Boolean availableOnly, String sortBy);
    List<ProductDto> getProductsByCategory(Long categoryId);
    List<ProductDto> getProductsBySellerEmail(String sellerEmail);
    List<ProductDto> getProductsBySellerId(Long sellerId);
    ProductDto createProduct(ProductRequest request, String userEmail);
    ProductDto updateProduct(Long id, ProductRequest request, String userEmail);
    void deleteProduct(Long id, String userEmail);
}
