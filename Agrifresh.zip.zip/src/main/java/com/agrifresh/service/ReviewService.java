package com.agrifresh.service;

import com.agrifresh.dto.ReviewDto;
import com.agrifresh.dto.ReviewRequest;

import java.util.List;

public interface ReviewService {
    List<ReviewDto> getReviewsForProduct(Long productId);
    ReviewDto addReview(Long productId, ReviewRequest request, String customerEmail);
}
