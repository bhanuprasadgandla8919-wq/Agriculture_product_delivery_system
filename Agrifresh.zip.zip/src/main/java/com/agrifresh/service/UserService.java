package com.agrifresh.service;

import com.agrifresh.dto.DashboardStatsDto;
import com.agrifresh.dto.ProfileUpdateRequest;
import com.agrifresh.dto.UserDto;

import java.util.List;

public interface UserService {
    UserDto getUserProfile(String email);
    UserDto updateUserProfile(String email, ProfileUpdateRequest request);
    List<UserDto> getAllUsers();
    List<UserDto> getAllSellers();
    UserDto toggleUserStatus(Long userId);
    DashboardStatsDto getSellerDashboardStats(String sellerEmail);
    DashboardStatsDto getAdminDashboardStats();
    DashboardStatsDto getCustomerDashboardStats(String customerEmail);
}
