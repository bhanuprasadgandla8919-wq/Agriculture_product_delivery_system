package com.agrifresh.service.impl;

import com.agrifresh.dto.AuthRequest;
import com.agrifresh.dto.AuthResponse;
import com.agrifresh.dto.RegisterRequest;
import com.agrifresh.entity.Cart;
import com.agrifresh.entity.Role;
import com.agrifresh.entity.Seller;
import com.agrifresh.entity.User;
import com.agrifresh.exception.BadRequestException;
import com.agrifresh.repository.CartRepository;
import com.agrifresh.repository.SellerRepository;
import com.agrifresh.repository.UserRepository;
import com.agrifresh.security.JwtUtils;
import com.agrifresh.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuthServiceImpl implements AuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private SellerRepository sellerRepository;

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtUtils jwtUtils;

    @Override
    @Transactional
    public AuthResponse register(RegisterRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new BadRequestException("Email is already registered: " + request.getEmail());
        }

        Role role = request.getRole() != null ? request.getRole() : Role.ROLE_CUSTOMER;

        User user = new User(
                request.getName(),
                request.getEmail(),
                request.getPhone(),
                passwordEncoder.encode(request.getPassword()),
                role,
                request.getAddress()
        );

        User savedUser = userRepository.save(user);

        Long sellerId = null;
        String farmName = null;
        String farmAddress = null;

        if (role == Role.ROLE_SELLER) {
            String fName = request.getFarmName() != null ? request.getFarmName() : request.getName() + "'s Farm";
            String fAddr = request.getFarmAddress() != null ? request.getFarmAddress() : request.getAddress();
            Seller seller = new Seller(savedUser, fName, fAddr);
            Seller savedSeller = sellerRepository.save(seller);
            sellerId = savedSeller.getId();
            farmName = savedSeller.getFarmName();
            farmAddress = savedSeller.getFarmAddress();
        } else if (role == Role.ROLE_CUSTOMER) {
            Cart cart = new Cart(savedUser);
            cartRepository.save(cart);
        }

        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
        );
        SecurityContextHolder.getContext().setAuthentication(authentication);
        String token = jwtUtils.generateJwtToken(authentication);

        return new AuthResponse(
                token,
                savedUser.getId(),
                savedUser.getName(),
                savedUser.getEmail(),
                savedUser.getPhone(),
                savedUser.getRole(),
                savedUser.getAddress(),
                sellerId,
                farmName,
                farmAddress
        );
    }

    @Override
    @Transactional
    public AuthResponse login(AuthRequest request) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
        );

        SecurityContextHolder.getContext().setAuthentication(authentication);
        String token = jwtUtils.generateJwtToken(authentication);

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new BadRequestException("User not found"));

        if (!user.isActive()) {
            throw new BadRequestException("Your account has been deactivated. Please contact support/admin.");
        }

        Long sellerId = null;
        String farmName = null;
        String farmAddress = null;

        if (user.getRole() == Role.ROLE_SELLER) {
            Seller seller = sellerRepository.findByUser(user).orElse(null);
            if (seller != null) {
                sellerId = seller.getId();
                farmName = seller.getFarmName();
                farmAddress = seller.getFarmAddress();
            }
        }

        // If customer doesn't have a cart yet, ensure one is created
        if (user.getRole() == Role.ROLE_CUSTOMER) {
            cartRepository.findByUser(user).orElseGet(() -> cartRepository.save(new Cart(user)));
        }

        return new AuthResponse(
                token,
                user.getId(),
                user.getName(),
                user.getEmail(),
                user.getPhone(),
                user.getRole(),
                user.getAddress(),
                sellerId,
                farmName,
                farmAddress
        );
    }
}
