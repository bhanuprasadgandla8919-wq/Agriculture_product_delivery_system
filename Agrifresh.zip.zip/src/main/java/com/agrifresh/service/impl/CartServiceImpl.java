package com.agrifresh.service.impl;

import com.agrifresh.dto.CartDto;
import com.agrifresh.dto.CartItemDto;
import com.agrifresh.dto.CartItemRequest;
import com.agrifresh.entity.*;
import com.agrifresh.exception.BadRequestException;
import com.agrifresh.exception.ResourceNotFoundException;
import com.agrifresh.repository.*;
import com.agrifresh.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class CartServiceImpl implements CartService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private CartItemRepository cartItemRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private UserRepository userRepository;

    private static final double FREE_DELIVERY_THRESHOLD = 500.0;
    private static final double STANDARD_DELIVERY_CHARGE = 40.0;

    @Override
    @Transactional
    public CartDto getCart(String userEmail) {
        Cart cart = getOrCreateCart(userEmail);
        return mapToCartDto(cart);
    }

    @Override
    @Transactional
    public CartDto addItemToCart(CartItemRequest request, String userEmail) {
        Cart cart = getOrCreateCart(userEmail);

        Product product = productRepository.findById(request.getProductId())
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + request.getProductId()));

        if (!product.isAvailable() || product.getStockQuantity() <= 0) {
            throw new BadRequestException("Product is currently out of stock");
        }

        Optional<CartItem> existingItemOpt = cartItemRepository.findByCartAndProduct(cart, product);

        if (existingItemOpt.isPresent()) {
            CartItem item = existingItemOpt.get();
            int newQuantity = item.getQuantity() + request.getQuantity();

            if (newQuantity > product.getStockQuantity()) {
                throw new BadRequestException("Cannot add " + request.getQuantity() + " more items. Only "
                        + product.getStockQuantity() + " " + product.getUnit() + " available in stock (already " + item.getQuantity() + " in cart)");
            }

            item.setQuantity(newQuantity);
            cartItemRepository.save(item);
        } else {
            if (request.getQuantity() > product.getStockQuantity()) {
                throw new BadRequestException("Requested quantity (" + request.getQuantity()
                        + ") exceeds available stock (" + product.getStockQuantity() + ")");
            }

            CartItem newItem = new CartItem(cart, product, request.getQuantity());
            cart.getItems().add(newItem);
            cartItemRepository.save(newItem);
        }

        return mapToCartDto(cart);
    }

    @Override
    @Transactional
    public CartDto updateCartItemQuantity(Long cartItemId, Integer quantity, String userEmail) {
        Cart cart = getOrCreateCart(userEmail);

        CartItem item = cartItemRepository.findById(cartItemId)
                .orElseThrow(() -> new ResourceNotFoundException("Cart item not found with id: " + cartItemId));

        if (!item.getCart().getId().equals(cart.getId())) {
            throw new BadRequestException("Item does not belong to your cart");
        }

        if (quantity <= 0) {
            cart.getItems().remove(item);
            cartItemRepository.delete(item);
        } else {
            if (quantity > item.getProduct().getStockQuantity()) {
                throw new BadRequestException("Cannot set quantity to " + quantity
                        + ". Only " + item.getProduct().getStockQuantity() + " available in stock");
            }
            item.setQuantity(quantity);
            cartItemRepository.save(item);
        }

        return mapToCartDto(cart);
    }

    @Override
    @Transactional
    public CartDto removeCartItem(Long cartItemId, String userEmail) {
        Cart cart = getOrCreateCart(userEmail);

        CartItem item = cartItemRepository.findById(cartItemId)
                .orElseThrow(() -> new ResourceNotFoundException("Cart item not found with id: " + cartItemId));

        if (!item.getCart().getId().equals(cart.getId())) {
            throw new BadRequestException("Item does not belong to your cart");
        }

        cart.getItems().remove(item);
        cartItemRepository.delete(item);

        return mapToCartDto(cart);
    }

    @Override
    @Transactional
    public void clearCart(String userEmail) {
        Cart cart = getOrCreateCart(userEmail);
        cart.getItems().clear();
        cartItemRepository.deleteByCart(cart);
    }

    private Cart getOrCreateCart(String userEmail) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + userEmail));

        return cartRepository.findByUser(user)
                .orElseGet(() -> cartRepository.save(new Cart(user)));
    }

    private CartDto mapToCartDto(Cart cart) {
        List<CartItemDto> itemDtos = new ArrayList<>();
        double subtotal = 0.0;
        int totalItems = 0;

        for (CartItem item : cart.getItems()) {
            Product p = item.getProduct();
            double itemSubtotal = p.getPrice() * item.getQuantity();
            subtotal += itemSubtotal;
            totalItems += item.getQuantity();

            CartItemDto dto = new CartItemDto();
            dto.setId(item.getId());
            dto.setProductId(p.getId());
            dto.setProductName(p.getName());
            dto.setProductImage(p.getImageUrl());
            dto.setPrice(p.getPrice());
            dto.setUnit(p.getUnit());
            dto.setQuantity(item.getQuantity());
            dto.setSubtotal(Math.round(itemSubtotal * 100.0) / 100.0);
            dto.setAvailableStock(p.getStockQuantity());
            if (p.getSeller() != null) {
                dto.setFarmName(p.getSeller().getFarmName());
            }

            itemDtos.add(dto);
        }

        double deliveryCharge = (subtotal > 0 && subtotal < FREE_DELIVERY_THRESHOLD) ? STANDARD_DELIVERY_CHARGE : 0.0;
        double totalAmount = subtotal + deliveryCharge;

        CartDto cartDto = new CartDto();
        cartDto.setId(cart.getId());
        cartDto.setItems(itemDtos);
        cartDto.setSubtotal(Math.round(subtotal * 100.0) / 100.0);
        cartDto.setDeliveryCharge(deliveryCharge);
        cartDto.setTotalAmount(Math.round(totalAmount * 100.0) / 100.0);
        cartDto.setTotalItems(totalItems);

        return cartDto;
    }
}
