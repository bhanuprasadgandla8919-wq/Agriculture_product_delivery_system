package com.agrifresh.service.impl;

import com.agrifresh.dto.OrderDto;
import com.agrifresh.dto.OrderItemDto;
import com.agrifresh.dto.OrderRequest;
import com.agrifresh.dto.PaymentDto;
import com.agrifresh.entity.*;
import com.agrifresh.exception.BadRequestException;
import com.agrifresh.exception.ResourceNotFoundException;
import com.agrifresh.exception.UnauthorizedException;
import com.agrifresh.repository.*;
import com.agrifresh.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private CartItemRepository cartItemRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PaymentRepository paymentRepository;

    private static final double FREE_DELIVERY_THRESHOLD = 500.0;
    private static final double STANDARD_DELIVERY_CHARGE = 40.0;

    @Override
    @Transactional
    public OrderDto createOrder(OrderRequest request, String customerEmail) {
        User customer = userRepository.findByEmail(customerEmail)
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found: " + customerEmail));

        Cart cart = cartRepository.findByUser(customer)
                .orElseThrow(() -> new BadRequestException("No cart found for user"));

        if (cart.getItems() == null || cart.getItems().isEmpty()) {
            throw new BadRequestException("Your cart is empty. Add products before placing an order.");
        }

        // Validate stock for all items
        for (CartItem item : cart.getItems()) {
            Product p = item.getProduct();
            if (p.getStockQuantity() < item.getQuantity()) {
                throw new BadRequestException("Insufficient stock for product '" + p.getName()
                        + "'. Available: " + p.getStockQuantity() + ", Requested: " + item.getQuantity());
            }
        }

        // Calculate totals
        double subtotal = 0.0;
        for (CartItem item : cart.getItems()) {
            subtotal += item.getProduct().getPrice() * item.getQuantity();
        }
        double deliveryCharge = (subtotal < FREE_DELIVERY_THRESHOLD) ? STANDARD_DELIVERY_CHARGE : 0.0;
        double totalAmount = subtotal + deliveryCharge;

        // Generate unique Order Number: e.g. ORD-20261007-AB12
        String datePart = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        String randPart = UUID.randomUUID().toString().substring(0, 4).toUpperCase();
        String orderNumber = "ORD-" + datePart + "-" + randPart;

        Order order = new Order();
        order.setOrderNumber(orderNumber);
        order.setCustomer(customer);
        order.setCustomerName(request.getCustomerName());
        order.setCustomerPhone(request.getPhone());
        order.setDeliveryAddress(request.getDeliveryAddress());
        order.setCity(request.getCity());
        order.setState(request.getState());
        order.setPincode(request.getPincode());
        order.setSubtotal(subtotal);
        order.setDeliveryCharge(deliveryCharge);
        order.setTotalAmount(Math.round(totalAmount * 100.0) / 100.0);
        order.setOrderStatus(OrderStatus.ORDER_PLACED);
        order.setOrderDate(LocalDateTime.now());
        order.setExpectedDeliveryDate(LocalDateTime.now().plusDays(2));

        // Create OrderItems and decrement product stock
        List<OrderItem> orderItems = new ArrayList<>();
        for (CartItem item : cart.getItems()) {
            Product product = item.getProduct();

            // Decrement stock
            int remainingStock = product.getStockQuantity() - item.getQuantity();
            product.setStockQuantity(remainingStock);
            product.setAvailable(remainingStock > 0);
            productRepository.save(product);

            double itemSubtotal = product.getPrice() * item.getQuantity();
            OrderItem orderItem = new OrderItem(
                    order,
                    product,
                    product.getSeller(),
                    item.getQuantity(),
                    product.getPrice(),
                    itemSubtotal
            );
            orderItems.add(orderItem);
        }
        order.setItems(orderItems);

        Order savedOrder = orderRepository.save(order);

        // Process Initial Payment record
        PaymentMethod method = request.getPaymentMethod() != null ? request.getPaymentMethod() : PaymentMethod.CASH_ON_DELIVERY;
        PaymentStatus status = (method == PaymentMethod.CASH_ON_DELIVERY) ? PaymentStatus.PENDING : PaymentStatus.SUCCESS;
        String txId = "TXN-" + System.currentTimeMillis();

        Payment payment = new Payment(savedOrder, method, status, txId, savedOrder.getTotalAmount());
        Payment savedPayment = paymentRepository.save(payment);
        savedOrder.setPayment(savedPayment);

        // Clear Customer Cart
        cart.getItems().clear();
        cartItemRepository.deleteByCart(cart);

        return mapToDto(savedOrder);
    }

    @Override
    @Transactional(readOnly = true)
    public OrderDto getOrderById(Long orderId, String userEmail) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with id: " + orderId));

        validateOrderAccess(order, userEmail);
        return mapToDto(order);
    }

    @Override
    @Transactional(readOnly = true)
    public OrderDto getOrderByOrderNumber(String orderNumber, String userEmail) {
        Order order = orderRepository.findByOrderNumber(orderNumber)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with order number: " + orderNumber));

        validateOrderAccess(order, userEmail);
        return mapToDto(order);
    }

    @Override
    @Transactional(readOnly = true)
    public List<OrderDto> getCustomerOrders(String customerEmail) {
        return orderRepository.findByCustomerEmailOrderByOrderDateDesc(customerEmail).stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<OrderDto> getSellerOrders(String sellerEmail) {
        return orderRepository.findOrdersBySellerEmail(sellerEmail).stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<OrderDto> getAllOrders() {
        return orderRepository.findAllByOrderByOrderDateDesc().stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public OrderDto updateOrderStatus(Long orderId, OrderStatus status, String userEmail) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with id: " + orderId));

        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + userEmail));

        // Only Admin or Seller whose items are in the order can update order status
        boolean isAdmin = user.getRole() == Role.ROLE_ADMIN;
        boolean isOrderSeller = order.getItems().stream()
                .anyMatch(item -> item.getSeller() != null && item.getSeller().getUser().getId().equals(user.getId()));

        if (!isAdmin && !isOrderSeller) {
            throw new UnauthorizedException("You are not authorized to update status for this order");
        }

        order.setOrderStatus(status);

        // If marked DELIVERED and payment was COD, update payment status to SUCCESS
        if (status == OrderStatus.DELIVERED && order.getPayment() != null
                && order.getPayment().getPaymentMethod() == PaymentMethod.CASH_ON_DELIVERY) {
            order.getPayment().setPaymentStatus(PaymentStatus.SUCCESS);
            paymentRepository.save(order.getPayment());
        }

        Order updated = orderRepository.save(order);
        return mapToDto(updated);
    }

    @Override
    @Transactional
    public OrderDto cancelOrder(Long orderId, String userEmail) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with id: " + orderId));

        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + userEmail));

        // Customer can only cancel their own order before it's OUT_FOR_DELIVERY / DELIVERED
        boolean isOwner = order.getCustomer().getId().equals(user.getId());
        boolean isAdmin = user.getRole() == Role.ROLE_ADMIN;

        if (!isOwner && !isAdmin) {
            throw new UnauthorizedException("You are not authorized to cancel this order");
        }

        if (order.getOrderStatus() == OrderStatus.OUT_FOR_DELIVERY || order.getOrderStatus() == OrderStatus.DELIVERED) {
            throw new BadRequestException("Order cannot be cancelled as it is already " + order.getOrderStatus());
        }

        if (order.getOrderStatus() == OrderStatus.CANCELLED) {
            throw new BadRequestException("Order is already cancelled");
        }

        order.setOrderStatus(OrderStatus.CANCELLED);

        // Restore product quantities
        for (OrderItem item : order.getItems()) {
            Product p = item.getProduct();
            p.setStockQuantity(p.getStockQuantity() + item.getQuantity());
            p.setAvailable(true);
            productRepository.save(p);
        }

        // Refund payment if already paid
        if (order.getPayment() != null && order.getPayment().getPaymentStatus() == PaymentStatus.SUCCESS) {
            order.getPayment().setPaymentStatus(PaymentStatus.REFUNDED);
            paymentRepository.save(order.getPayment());
        }

        Order updated = orderRepository.save(order);
        return mapToDto(updated);
    }

    private void validateOrderAccess(Order order, String userEmail) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + userEmail));

        if (user.getRole() == Role.ROLE_ADMIN) return;

        boolean isCustomer = order.getCustomer().getId().equals(user.getId());
        boolean isSeller = order.getItems().stream()
                .anyMatch(item -> item.getSeller() != null && item.getSeller().getUser().getId().equals(user.getId()));

        if (!isCustomer && !isSeller) {
            throw new UnauthorizedException("You do not have permission to view this order");
        }
    }

    private OrderDto mapToDto(Order order) {
        OrderDto dto = new OrderDto();
        dto.setId(order.getId());
        dto.setOrderNumber(order.getOrderNumber());
        if (order.getCustomer() != null) {
            dto.setCustomerId(order.getCustomer().getId());
            dto.setCustomerEmail(order.getCustomer().getEmail());
        }
        dto.setCustomerName(order.getCustomerName());
        dto.setCustomerPhone(order.getCustomerPhone());
        dto.setDeliveryAddress(order.getDeliveryAddress());
        dto.setCity(order.getCity());
        dto.setState(order.getState());
        dto.setPincode(order.getPincode());
        dto.setSubtotal(order.getSubtotal());
        dto.setTotalAmount(order.getTotalAmount());
        dto.setDeliveryCharge(order.getDeliveryCharge());
        dto.setOrderStatus(order.getOrderStatus());
        dto.setOrderDate(order.getOrderDate());
        dto.setExpectedDeliveryDate(order.getExpectedDeliveryDate());

        List<OrderItemDto> itemDtos = order.getItems().stream().map(item -> {
            OrderItemDto itemDto = new OrderItemDto();
            itemDto.setId(item.getId());
            if (item.getProduct() != null) {
                itemDto.setProductId(item.getProduct().getId());
                itemDto.setProductName(item.getProduct().getName());
                itemDto.setProductImage(item.getProduct().getImageUrl());
                itemDto.setUnit(item.getProduct().getUnit());
            }
            if (item.getSeller() != null) {
                itemDto.setSellerId(item.getSeller().getId());
                itemDto.setFarmName(item.getSeller().getFarmName());
            }
            itemDto.setQuantity(item.getQuantity());
            itemDto.setPrice(item.getPrice());
            itemDto.setSubtotal(item.getSubtotal());
            return itemDto;
        }).collect(Collectors.toList());

        dto.setItems(itemDtos);

        if (order.getPayment() != null) {
            Payment p = order.getPayment();
            PaymentDto pDto = new PaymentDto(
                    p.getId(),
                    order.getId(),
                    order.getOrderNumber(),
                    p.getPaymentMethod(),
                    p.getPaymentStatus(),
                    p.getTransactionId(),
                    p.getAmount(),
                    p.getPaymentDate()
            );
            dto.setPayment(pDto);
        }

        return dto;
    }
}
