package com.agrifresh.service.impl;

import com.agrifresh.dto.PaymentDto;
import com.agrifresh.dto.PaymentRequest;
import com.agrifresh.entity.*;
import com.agrifresh.exception.BadRequestException;
import com.agrifresh.exception.ResourceNotFoundException;
import com.agrifresh.exception.UnauthorizedException;
import com.agrifresh.repository.OrderRepository;
import com.agrifresh.repository.PaymentRepository;
import com.agrifresh.repository.UserRepository;
import com.agrifresh.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
public class PaymentServiceImpl implements PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    @Transactional
    public PaymentDto processPayment(PaymentRequest request, String userEmail) {
        Order order = orderRepository.findById(request.getOrderId())
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with id: " + request.getOrderId()));

        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + userEmail));

        if (user.getRole() != Role.ROLE_ADMIN && !order.getCustomer().getId().equals(user.getId())) {
            throw new UnauthorizedException("You are not authorized to make payment for this order");
        }

        Payment payment = paymentRepository.findByOrderId(order.getId())
                .orElseGet(() -> new Payment(order, request.getPaymentMethod(), PaymentStatus.PENDING, null, order.getTotalAmount()));

        payment.setPaymentMethod(request.getPaymentMethod());

        // Process Mock Payment: Never store sensitive card/CVV data
        if (request.getPaymentMethod() == PaymentMethod.CASH_ON_DELIVERY) {
            payment.setPaymentStatus(PaymentStatus.PENDING);
            payment.setTransactionId("COD-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        } else {
            // Simulated instant online payment approval
            payment.setPaymentStatus(PaymentStatus.SUCCESS);
            String prefix = request.getPaymentMethod() == PaymentMethod.UPI ? "UPI-" : "CARD-";
            payment.setTransactionId(prefix + System.currentTimeMillis() + "-" + UUID.randomUUID().toString().substring(0, 4).toUpperCase());
            payment.setPaymentDate(LocalDateTime.now());
        }

        Payment saved = paymentRepository.save(payment);
        return mapToDto(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public PaymentDto getPaymentByOrderId(Long orderId, String userEmail) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with id: " + orderId));

        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + userEmail));

        boolean isAdmin = user.getRole() == Role.ROLE_ADMIN;
        boolean isOwner = order.getCustomer().getId().equals(user.getId());
        boolean isSeller = order.getItems().stream()
                .anyMatch(item -> item.getSeller() != null && item.getSeller().getUser().getId().equals(user.getId()));

        if (!isAdmin && !isOwner && !isSeller) {
            throw new UnauthorizedException("You are not authorized to view payment details for this order");
        }

        Payment payment = paymentRepository.findByOrderId(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Payment details not found for order id: " + orderId));

        return mapToDto(payment);
    }

    private PaymentDto mapToDto(Payment p) {
        return new PaymentDto(
                p.getId(),
                p.getOrder().getId(),
                p.getOrder().getOrderNumber(),
                p.getPaymentMethod(),
                p.getPaymentStatus(),
                p.getTransactionId(),
                p.getAmount(),
                p.getPaymentDate()
        );
    }
}
