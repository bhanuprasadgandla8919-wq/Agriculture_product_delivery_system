package com.agrifresh.service.impl;

import com.agrifresh.dto.ProductDto;
import com.agrifresh.dto.ProductRequest;
import com.agrifresh.entity.*;
import com.agrifresh.exception.BadRequestException;
import com.agrifresh.exception.ResourceNotFoundException;
import com.agrifresh.exception.UnauthorizedException;
import com.agrifresh.repository.*;
import com.agrifresh.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private SellerRepository sellerRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ReviewRepository reviewRepository;

    @Override
    @Transactional(readOnly = true)
    public List<ProductDto> getAllProducts() {
        return productRepository.findByAvailableTrue().stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public ProductDto getProductById(Long id) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + id));
        return mapToDto(product);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProductDto> searchAndFilterProducts(String keyword, Long categoryId, Double minPrice,
                                                    Double maxPrice, Long sellerId, Boolean availableOnly, String sortBy) {
        if (keyword != null && keyword.trim().isEmpty()) {
            keyword = null;
        }

        List<Product> products = productRepository.searchAndFilterProducts(
                keyword, categoryId, minPrice, maxPrice, sellerId, availableOnly
        );

        List<ProductDto> dtos = products.stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());

        if (sortBy != null) {
            switch (sortBy.toLowerCase()) {
                case "price_asc":
                    dtos.sort(Comparator.comparing(ProductDto::getPrice));
                    break;
                case "price_desc":
                    dtos.sort(Comparator.comparing(ProductDto::getPrice).reversed());
                    break;
                case "name_asc":
                    dtos.sort(Comparator.comparing(ProductDto::getName, String.CASE_INSENSITIVE_ORDER));
                    break;
                case "newest":
                default:
                    dtos.sort((a, b) -> {
                        if (a.getCreatedAt() == null || b.getCreatedAt() == null) return 0;
                        return b.getCreatedAt().compareTo(a.getCreatedAt());
                    });
                    break;
            }
        }

        return dtos;
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProductDto> getProductsByCategory(Long categoryId) {
        return productRepository.findByCategoryIdAndAvailableTrue(categoryId).stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProductDto> getProductsBySellerEmail(String sellerEmail) {
        return productRepository.findBySellerUserEmail(sellerEmail).stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProductDto> getProductsBySellerId(Long sellerId) {
        return productRepository.findBySellerId(sellerId).stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public ProductDto createProduct(ProductRequest request, String userEmail) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + userEmail));

        Seller seller = sellerRepository.findByUser(user)
                .orElseThrow(() -> new BadRequestException("User is not registered as a seller/farmer"));

        Category category = categoryRepository.findById(request.getCategoryId())
                .orElseThrow(() -> new ResourceNotFoundException("Category not found with id: " + request.getCategoryId()));

        String imgUrl = request.getImageUrl();
        if (imgUrl == null || imgUrl.trim().isEmpty()) {
            imgUrl = "https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80";
        }

        Product product = new Product(
                seller,
                category,
                request.getName(),
                request.getDescription(),
                request.getPrice(),
                request.getStockQuantity(),
                request.getUnit(),
                imgUrl
        );

        if (request.getAvailable() != null) {
            product.setAvailable(request.getAvailable() && request.getStockQuantity() > 0);
        }

        Product saved = productRepository.save(product);
        return mapToDto(saved);
    }

    @Override
    @Transactional
    public ProductDto updateProduct(Long id, ProductRequest request, String userEmail) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + id));

        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + userEmail));

        // Security check: Only the owning seller or ADMIN can update
        if (user.getRole() != Role.ROLE_ADMIN && !product.getSeller().getUser().getId().equals(user.getId())) {
            throw new UnauthorizedException("You are not authorized to update this product");
        }

        Category category = categoryRepository.findById(request.getCategoryId())
                .orElseThrow(() -> new ResourceNotFoundException("Category not found with id: " + request.getCategoryId()));

        product.setCategory(category);
        product.setName(request.getName());
        product.setDescription(request.getDescription());
        product.setPrice(request.getPrice());
        product.setStockQuantity(request.getStockQuantity());
        product.setUnit(request.getUnit());

        if (request.getImageUrl() != null && !request.getImageUrl().trim().isEmpty()) {
            product.setImageUrl(request.getImageUrl());
        }

        if (request.getAvailable() != null) {
            product.setAvailable(request.getAvailable() && request.getStockQuantity() > 0);
        } else {
            product.setAvailable(request.getStockQuantity() > 0);
        }

        Product updated = productRepository.save(product);
        return mapToDto(updated);
    }

    @Override
    @Transactional
    public void deleteProduct(Long id, String userEmail) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + id));

        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + userEmail));

        // Security check: Only the owning seller or ADMIN can delete
        if (user.getRole() != Role.ROLE_ADMIN && !product.getSeller().getUser().getId().equals(user.getId())) {
            throw new UnauthorizedException("You are not authorized to delete this product");
        }

        productRepository.delete(product);
    }

    private ProductDto mapToDto(Product p) {
        ProductDto dto = new ProductDto();
        dto.setId(p.getId());
        dto.setName(p.getName());
        dto.setDescription(p.getDescription());
        dto.setPrice(p.getPrice());
        dto.setStockQuantity(p.getStockQuantity());
        dto.setUnit(p.getUnit());
        dto.setImageUrl(p.getImageUrl());
        dto.setAvailable(p.isAvailable());
        dto.setCreatedAt(p.getCreatedAt());

        if (p.getCategory() != null) {
            dto.setCategoryId(p.getCategory().getId());
            dto.setCategoryName(p.getCategory().getName());
        }

        if (p.getSeller() != null) {
            dto.setSellerId(p.getSeller().getId());
            dto.setSellerName(p.getSeller().getUser() != null ? p.getSeller().getUser().getName() : "Farmer");
            dto.setFarmName(p.getSeller().getFarmName());
            dto.setFarmAddress(p.getSeller().getFarmAddress());
        }

        Double avgRating = reviewRepository.getAverageRatingForProduct(p.getId());
        dto.setAverageRating(avgRating != null ? Math.round(avgRating * 10.0) / 10.0 : 0.0);
        dto.setReviewCount(reviewRepository.countByProductId(p.getId()));

        return dto;
    }
}
