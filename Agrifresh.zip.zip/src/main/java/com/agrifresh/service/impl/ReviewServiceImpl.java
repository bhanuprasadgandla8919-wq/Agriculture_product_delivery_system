package com.agrifresh.service.impl;

import com.agrifresh.dto.ReviewDto;
import com.agrifresh.dto.ReviewRequest;
import com.agrifresh.entity.Product;
import com.agrifresh.entity.Review;
import com.agrifresh.entity.User;
import com.agrifresh.exception.ResourceNotFoundException;
import com.agrifresh.repository.ProductRepository;
import com.agrifresh.repository.ReviewRepository;
import com.agrifresh.repository.UserRepository;
import com.agrifresh.service.ReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ReviewServiceImpl implements ReviewService {

    @Autowired
    private ReviewRepository reviewRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    @Transactional(readOnly = true)
    public List<ReviewDto> getReviewsForProduct(Long productId) {
        return reviewRepository.findByProductIdOrderByCreatedAtDesc(productId).stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public ReviewDto addReview(Long productId, ReviewRequest request, String customerEmail) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + productId));

        User customer = userRepository.findByEmail(customerEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + customerEmail));

        Review review = new Review(product, customer, request.getRating(), request.getComment());
        review.setCreatedAt(LocalDateTime.now());

        Review saved = reviewRepository.save(review);
        return mapToDto(saved);
    }

    private ReviewDto mapToDto(Review r) {
        return new ReviewDto(
                r.getId(),
                r.getProduct().getId(),
                r.getCustomer().getName(),
                r.getRating(),
                r.getComment(),
                r.getCreatedAt()
        );
    }
}
