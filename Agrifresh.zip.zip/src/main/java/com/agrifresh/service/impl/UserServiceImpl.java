package com.agrifresh.service.impl;

import com.agrifresh.dto.DashboardStatsDto;
import com.agrifresh.dto.ProfileUpdateRequest;
import com.agrifresh.dto.UserDto;
import com.agrifresh.entity.*;
import com.agrifresh.exception.BadRequestException;
import com.agrifresh.exception.ResourceNotFoundException;
import com.agrifresh.repository.*;
import com.agrifresh.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private SellerRepository sellerRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Override
    @Transactional(readOnly = true)
    public UserDto getUserProfile(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + email));
        return mapToDto(user);
    }

    @Override
    @Transactional
    public UserDto updateUserProfile(String email, ProfileUpdateRequest request) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + email));

        user.setName(request.getName());
        user.setPhone(request.getPhone());
        user.setAddress(request.getAddress());

        if (user.getRole() == Role.ROLE_SELLER) {
            Seller seller = sellerRepository.findByUser(user)
                    .orElseGet(() -> new Seller(user, request.getFarmName(), request.getFarmAddress()));

            if (request.getFarmName() != null && !request.getFarmName().trim().isEmpty()) {
                seller.setFarmName(request.getFarmName());
            }
            if (request.getFarmAddress() != null && !request.getFarmAddress().trim().isEmpty()) {
                seller.setFarmAddress(request.getFarmAddress());
            }
            sellerRepository.save(seller);
        }

        User updated = userRepository.save(user);
        return mapToDto(updated);
    }

    @Override
    @Transactional(readOnly = true)
    public List<UserDto> getAllUsers() {
        return userRepository.findAll().stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<UserDto> getAllSellers() {
        return userRepository.findByRole(Role.ROLE_SELLER).stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public UserDto toggleUserStatus(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));

        if (user.getRole() == Role.ROLE_ADMIN) {
            throw new BadRequestException("Cannot deactivate Admin user");
        }

        user.setActive(!user.isActive());
        User updated = userRepository.save(user);
        return mapToDto(updated);
    }

    @Override
    @Transactional(readOnly = true)
    public DashboardStatsDto getSellerDashboardStats(String sellerEmail) {
        Seller seller = sellerRepository.findByUserEmail(sellerEmail)
                .orElseThrow(() -> new BadRequestException("Seller profile not found for email: " + sellerEmail));

        Long sellerId = seller.getId();
        long totalProducts = productRepository.countBySellerId(sellerId);
        long totalOrders = orderRepository.countOrdersBySellerId(sellerId);
        long pendingOrders = orderRepository.countOrdersBySellerIdAndStatus(sellerId, OrderStatus.ORDER_PLACED)
                + orderRepository.countOrdersBySellerIdAndStatus(sellerId, OrderStatus.CONFIRMED)
                + orderRepository.countOrdersBySellerIdAndStatus(sellerId, OrderStatus.PACKED)
                + orderRepository.countOrdersBySellerIdAndStatus(sellerId, OrderStatus.OUT_FOR_DELIVERY);
        long completedOrders = orderRepository.countOrdersBySellerIdAndStatus(sellerId, OrderStatus.DELIVERED);
        Double revenue = orderRepository.calculateSellerRevenue(sellerId);

        DashboardStatsDto stats = new DashboardStatsDto();
        stats.setTotalProducts(totalProducts);
        stats.setTotalOrders(totalOrders);
        stats.setPendingOrders(pendingOrders);
        stats.setCompletedOrders(completedOrders);
        stats.setTotalRevenue(revenue != null ? Math.round(revenue * 100.0) / 100.0 : 0.0);

        return stats;
    }

    @Override
    @Transactional(readOnly = true)
    public DashboardStatsDto getAdminDashboardStats() {
        long totalProducts = productRepository.count();
        long totalOrders = orderRepository.count();
        long pendingOrders = orderRepository.countByOrderStatus(OrderStatus.ORDER_PLACED)
                + orderRepository.countByOrderStatus(OrderStatus.CONFIRMED)
                + orderRepository.countByOrderStatus(OrderStatus.PACKED)
                + orderRepository.countByOrderStatus(OrderStatus.OUT_FOR_DELIVERY);
        long completedOrders = orderRepository.countByOrderStatus(OrderStatus.DELIVERED);
        Double totalRevenue = orderRepository.calculateTotalSystemRevenue();

        long customers = userRepository.countByRole(Role.ROLE_CUSTOMER);
        long sellers = userRepository.countByRole(Role.ROLE_SELLER);
        long categories = categoryRepository.count();

        DashboardStatsDto stats = new DashboardStatsDto();
        stats.setTotalProducts(totalProducts);
        stats.setTotalOrders(totalOrders);
        stats.setPendingOrders(pendingOrders);
        stats.setCompletedOrders(completedOrders);
        stats.setTotalRevenue(totalRevenue != null ? Math.round(totalRevenue * 100.0) / 100.0 : 0.0);
        stats.setTotalCustomers(customers);
        stats.setTotalSellers(sellers);
        stats.setTotalCategories(categories);

        return stats;
    }

    @Override
    @Transactional(readOnly = true)
    public DashboardStatsDto getCustomerDashboardStats(String customerEmail) {
        List<Order> orders = orderRepository.findByCustomerEmailOrderByOrderDateDesc(customerEmail);
        long totalOrders = orders.size();
        long completedOrders = orders.stream().filter(o -> o.getOrderStatus() == OrderStatus.DELIVERED).count();
        long pendingOrders = orders.stream().filter(o -> o.getOrderStatus() != OrderStatus.DELIVERED && o.getOrderStatus() != OrderStatus.CANCELLED).count();
        double totalSpent = orders.stream()
                .filter(o -> o.getOrderStatus() != OrderStatus.CANCELLED)
                .mapToDouble(Order::getTotalAmount)
                .sum();

        DashboardStatsDto stats = new DashboardStatsDto();
        stats.setTotalOrders(totalOrders);
        stats.setPendingOrders(pendingOrders);
        stats.setCompletedOrders(completedOrders);
        stats.setTotalRevenue(Math.round(totalSpent * 100.0) / 100.0);

        return stats;
    }

    private UserDto mapToDto(User u) {
        UserDto dto = new UserDto();
        dto.setId(u.getId());
        dto.setName(u.getName());
        dto.setEmail(u.getEmail());
        dto.setPhone(u.getPhone());
        dto.setRole(u.getRole());
        dto.setAddress(u.getAddress());
        dto.setActive(u.isActive());
        dto.setCreatedAt(u.getCreatedAt());

        if (u.getRole() == Role.ROLE_SELLER) {
            sellerRepository.findByUser(u).ifPresent(s -> {
                dto.setSellerId(s.getId());
                dto.setFarmName(s.getFarmName());
                dto.setFarmAddress(s.getFarmAddress());
            });
        }

        return dto;
    }
}
