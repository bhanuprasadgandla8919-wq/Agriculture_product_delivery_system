/**
 * AgriFresh – Central API and Application Client
 * Connects frontend HTML/JS to Spring Boot REST APIs
 * Includes intelligent offline mock fallback when backend is starting up
 */

const API_BASE_URL = '/api';

// Initial Mock Seed Data for offline fallback
const DEFAULT_CATEGORIES = [
    { id: 1, name: "Vegetables", description: "Farm-fresh crunchy vegetables grown naturally and harvested daily.", imageUrl: "https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80", productCount: 3 },
    { id: 2, name: "Fruits", description: "Naturally sweetened, juicy seasonal and tropical farm fruits.", imageUrl: "https://images.unsplash.com/photo-1619566636858-adf3ef46400b?auto=format&fit=crop&w=600&q=80", productCount: 2 },
    { id: 3, name: "Grains", description: "Whole grains, basmati rice, wheat and traditional millets.", imageUrl: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&w=600&q=80", productCount: 1 },
    { id: 4, name: "Pulses", description: "Unpolished lentils, chickpeas, and protein-packed organic dals.", imageUrl: "https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80", productCount: 1 },
    { id: 5, name: "Dairy Products", description: "Fresh A2 cow milk, artisanal paneer, churned butter and ghee.", imageUrl: "https://images.unsplash.com/photo-1550583724-b2692b85b150?auto=format&fit=crop&w=600&q=80", productCount: 1 },
    { id: 6, name: "Organic Products", description: "100% Certified chemical-free, pesticide-free harvest and greens.", imageUrl: "https://images.unsplash.com/photo-1610348725531-843dff563e2c?auto=format&fit=crop&w=600&q=80", productCount: 1 },
    { id: 7, name: "Seeds", description: "High-germination vegetable, flower and crop seeds for farming.", imageUrl: "https://images.unsplash.com/photo-1516253593875-bd7ba052fbc5?auto=format&fit=crop&w=600&q=80", productCount: 1 },
    { id: 8, name: "Spices", description: "Aromatic whole and ground spices straight from coastal plantations.", imageUrl: "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=600&q=80", productCount: 1 },
    { id: 9, name: "Honey", description: "Raw, unprocessed pure forest honey collected directly by beekeepers.", imageUrl: "https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=600&q=80", productCount: 1 },
    { id: 10, name: "Other Farm Products", description: "Cold-pressed oils, jaggery, compost, and natural agro essentials.", imageUrl: "https://images.unsplash.com/photo-1471193945509-9ad0617afabf?auto=format&fit=crop&w=600&q=80", productCount: 1 }
];

const DEFAULT_PRODUCTS = [
    { id: 1, categoryId: 1, categoryName: "Vegetables", sellerId: 1, sellerName: "Ramesh Patil", farmName: "Green Valley Organic Farm", farmAddress: "Nashik, Maharashtra", name: "Organic Red Tomatoes", description: "Juicy, vine-ripened organic red tomatoes with rich flavor, grown without synthetic pesticides.", price: 45.0, stockQuantity: 150, unit: "kg", imageUrl: "https://images.unsplash.com/photo-1592924357228-91a4daadcfea?auto=format&fit=crop&w=600&q=80", available: true, averageRating: 4.8, reviewCount: 12, createdAt: "2026-10-06T10:00:00" },
    { id: 2, categoryId: 1, categoryName: "Vegetables", sellerId: 1, sellerName: "Ramesh Patil", farmName: "Green Valley Organic Farm", farmAddress: "Nashik, Maharashtra", name: "Crisp Green Capsicum", description: "Farm-fresh crisp bell peppers, ideal for stir-fries, salads, and healthy cooking.", price: 60.0, stockQuantity: 80, unit: "kg", imageUrl: "https://images.unsplash.com/photo-1563565375-f3fdfdbefa83?auto=format&fit=crop&w=600&q=80", available: true, averageRating: 4.6, reviewCount: 7, createdAt: "2026-10-06T11:00:00" },
    { id: 3, categoryId: 1, categoryName: "Vegetables", sellerId: 2, sellerName: "Sita Devi", farmName: "Sunrise Agro Farms", farmAddress: "Pune, Maharashtra", name: "Farm Fresh Spinach (Palak)", description: "Tender organic green spinach bunches harvested early morning. Packed with natural iron and folate.", price: 25.0, stockQuantity: 100, unit: "bunch", imageUrl: "https://images.unsplash.com/photo-1576045057995-568f588f82fb?auto=format&fit=crop&w=600&q=80", available: true, averageRating: 4.9, reviewCount: 15, createdAt: "2026-10-06T09:30:00" },
    { id: 4, categoryId: 2, categoryName: "Fruits", sellerId: 1, sellerName: "Ramesh Patil", farmName: "Green Valley Organic Farm", farmAddress: "Nashik, Maharashtra", name: "Shimla Royal Delicious Apples", description: "Sweet, crunchy high-altitude mountain apples freshly handpicked from orchards.", price: 180.0, stockQuantity: 75, unit: "kg", imageUrl: "https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?auto=format&fit=crop&w=600&q=80", available: true, averageRating: 4.7, reviewCount: 9, createdAt: "2026-10-06T08:00:00" },
    { id: 5, categoryId: 2, categoryName: "Fruits", sellerId: 2, sellerName: "Sita Devi", farmName: "Sunrise Agro Farms", farmAddress: "Pune, Maharashtra", name: "Nagpur Sweet Oranges", description: "Juicy, vitamin-C rich sweet oranges harvested directly from Vidarbha farms.", price: 80.0, stockQuantity: 120, unit: "kg", imageUrl: "https://images.unsplash.com/photo-1611080626919-7cf5a9dbab5b?auto=format&fit=crop&w=600&q=80", available: true, averageRating: 4.5, reviewCount: 8, createdAt: "2026-10-06T10:30:00" },
    { id: 6, categoryId: 3, categoryName: "Grains", sellerId: 1, sellerName: "Ramesh Patil", farmName: "Green Valley Organic Farm", farmAddress: "Nashik, Maharashtra", name: "Traditional Basmati Rice (Aged 2 Years)", description: "Extra long grain aromatic basmati rice aged naturally for superior fluffy texture.", price: 140.0, stockQuantity: 200, unit: "kg", imageUrl: "https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80", available: true, averageRating: 5.0, reviewCount: 22, createdAt: "2026-10-05T12:00:00" },
    { id: 7, categoryId: 4, categoryName: "Pulses", sellerId: 2, sellerName: "Sita Devi", farmName: "Sunrise Agro Farms", farmAddress: "Pune, Maharashtra", name: "Organic Unpolished Toor Dal", description: "Nutritious, high-protein yellow pigeon peas without any chemical polishing.", price: 160.0, stockQuantity: 90, unit: "kg", imageUrl: "https://images.unsplash.com/photo-1515543237350-b3eea1ec8082?auto=format&fit=crop&w=600&q=80", available: true, averageRating: 4.8, reviewCount: 11, createdAt: "2026-10-05T14:00:00" },
    { id: 8, categoryId: 5, categoryName: "Dairy Products", sellerId: 1, sellerName: "Ramesh Patil", farmName: "Green Valley Organic Farm", farmAddress: "Nashik, Maharashtra", name: "Pure A2 Gir Cow Desi Ghee", description: "Traditional Bilona method churned golden ghee made from pasture-raised Gir cow milk.", price: 750.0, stockQuantity: 45, unit: "litre", imageUrl: "https://images.unsplash.com/photo-1631451095765-2c91616fc9e6?auto=format&fit=crop&w=600&q=80", available: true, averageRating: 5.0, reviewCount: 34, createdAt: "2026-10-05T15:00:00" },
    { id: 9, categoryId: 9, categoryName: "Honey", sellerId: 2, sellerName: "Sita Devi", farmName: "Sunrise Agro Farms", farmAddress: "Pune, Maharashtra", name: "Raw Wildflower Forest Honey", description: "Unheated, unpasteurized 100% natural pure honey retaining all natural pollen notes.", price: 380.0, stockQuantity: 60, unit: "kg", imageUrl: "https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=600&q=80", available: true, averageRating: 4.9, reviewCount: 19, createdAt: "2026-10-05T16:00:00" }
];

function getMockStorage(key, defaultVal) {
    const v = localStorage.getItem('agrifresh_' + key);
    if (!v) {
        localStorage.setItem('agrifresh_' + key, JSON.stringify(defaultVal));
        return defaultVal;
    }
    return JSON.parse(v);
}

function setMockStorage(key, val) {
    localStorage.setItem('agrifresh_' + key, JSON.stringify(val));
}

const AgriAPI = {
    // Session Management
    getToken() {
        return localStorage.getItem('agrifresh_token');
    },

    setToken(token) {
        localStorage.setItem('agrifresh_token', token);
    },

    getCurrentUser() {
        const u = localStorage.getItem('agrifresh_user');
        return u ? JSON.parse(u) : null;
    },

    setCurrentUser(user) {
        localStorage.setItem('agrifresh_user', JSON.stringify(user));
    },

    logout() {
        localStorage.removeItem('agrifresh_token');
        localStorage.removeItem('agrifresh_user');
        window.location.href = 'login.html';
    },

    // Core Fetch Wrapper with Graceful Fallback
    async request(endpoint, options = {}) {
        const headers = {
            'Content-Type': 'application/json',
            ...(options.headers || {})
        };

        const token = this.getToken();
        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }

        try {
            const response = await fetch(`${API_BASE_URL}${endpoint}`, {
                ...options,
                headers
            });

            if (response.ok) {
                const data = await response.json();
                return data;
            }
        } catch (netErr) {
            // Backend offline - use local demo mock engine
            console.warn(`Spring Boot backend offline at ${endpoint}. Using offline mock engine.`);
        }

        // Offline Mock Fallback Processor
        return this.handleOfflineMock(endpoint, options);
    },

    handleOfflineMock(endpoint, options) {
        const method = options.method || 'GET';
        const body = options.body ? JSON.parse(options.body) : {};
        const user = this.getCurrentUser();

        // 1. Auth Login
        if (endpoint === '/auth/login' && method === 'POST') {
            let role = 'ROLE_CUSTOMER';
            let name = 'Rahul Sharma';
            let farmName = null;
            let farmAddress = null;

            if (body.email.includes('admin')) {
                role = 'ROLE_ADMIN';
                name = 'System Administrator';
            } else if (body.email.includes('farm') || body.email.includes('seller') || body.email.includes('ramesh') || body.email.includes('sita')) {
                role = 'ROLE_SELLER';
                name = 'Ramesh Patil';
                farmName = 'Green Valley Organic Farm';
                farmAddress = 'Dindori Valley, Nashik, Maharashtra';
            }

            const mockUser = {
                id: 1,
                name: name,
                email: body.email,
                phone: '+91 9876543210',
                role: role,
                address: 'Pune, Maharashtra',
                token: 'mock-jwt-token-' + Date.now(),
                sellerId: role === 'ROLE_SELLER' ? 1 : null,
                farmName: farmName,
                farmAddress: farmAddress
            };
            return { success: true, message: 'Login successful (Offline Demo Mode)', data: mockUser };
        }

        // 2. Auth Register
        if (endpoint === '/auth/register' && method === 'POST') {
            const role = body.role || 'ROLE_CUSTOMER';
            const mockUser = {
                id: Date.now(),
                name: body.name,
                email: body.email,
                phone: body.phone,
                role: role,
                address: body.address,
                token: 'mock-jwt-token-' + Date.now(),
                sellerId: role === 'ROLE_SELLER' ? Date.now() : null,
                farmName: body.farmName || null,
                farmAddress: body.farmAddress || null
            };
            return { success: true, message: 'Registration successful', data: mockUser };
        }

        // 3. Categories
        if (endpoint.startsWith('/categories') && method === 'GET') {
            const cats = getMockStorage('categories', DEFAULT_CATEGORIES);
            return { success: true, data: cats };
        }

        // 4. Products
        if (endpoint === '/products' && method === 'GET') {
            const prods = getMockStorage('products', DEFAULT_PRODUCTS);
            return { success: true, data: prods };
        }

        if (endpoint.startsWith('/products/') && !endpoint.includes('search') && !endpoint.includes('reviews') && method === 'GET') {
            const id = parseInt(endpoint.split('/')[2]);
            const prods = getMockStorage('products', DEFAULT_PRODUCTS);
            const found = prods.find(p => p.id === id) || prods[0];
            return { success: true, data: found };
        }

        if (endpoint.startsWith('/products/search')) {
            const prods = getMockStorage('products', DEFAULT_PRODUCTS);
            const urlObj = new URL('http://dummy.com' + endpoint);
            const kw = urlObj.searchParams.get('keyword');
            const catId = urlObj.searchParams.get('categoryId');
            const minP = urlObj.searchParams.get('minPrice');
            const maxP = urlObj.searchParams.get('maxPrice');
            const avail = urlObj.searchParams.get('availableOnly');
            const sort = urlObj.searchParams.get('sortBy');

            let filtered = prods.filter(p => {
                if (kw && !p.name.toLowerCase().includes(kw.toLowerCase()) && !p.description.toLowerCase().includes(kw.toLowerCase())) return false;
                if (catId && p.categoryId != catId) return false;
                if (minP && p.price < parseFloat(minP)) return false;
                if (maxP && p.price > parseFloat(maxP)) return false;
                if (avail === 'true' && (!p.available || p.stockQuantity <= 0)) return false;
                return true;
            });

            if (sort === 'price_asc') filtered.sort((a,b) => a.price - b.price);
            else if (sort === 'price_desc') filtered.sort((a,b) => b.price - a.price);

            return { success: true, data: filtered };
        }

        if (endpoint === '/products' && method === 'POST') {
            const prods = getMockStorage('products', DEFAULT_PRODUCTS);
            const cats = getMockStorage('categories', DEFAULT_CATEGORIES);
            const cat = cats.find(c => c.id === body.categoryId) || cats[0];
            const defaultImg = "https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80";

            const newProduct = {
                id: Date.now(),
                categoryId: cat ? cat.id : 1,
                categoryName: cat ? cat.name : "Vegetables",
                sellerId: user && user.sellerId ? user.sellerId : 1,
                sellerName: user ? user.name : "Ramesh Patil",
                farmName: user && user.farmName ? user.farmName : "Green Valley Organic Farm",
                farmAddress: user && user.farmAddress ? user.farmAddress : "Nashik, Maharashtra",
                name: body.name,
                description: body.description || "Farm-fresh natural produce, grown responsibly.",
                price: parseFloat(body.price),
                stockQuantity: parseInt(body.stockQuantity),
                unit: body.unit || "kg",
                imageUrl: (body.imageUrl && body.imageUrl.trim().length > 5) ? body.imageUrl.trim() : defaultImg,
                available: body.available !== false && parseInt(body.stockQuantity) > 0,
                averageRating: 5.0,
                reviewCount: 1,
                createdAt: new Date().toISOString()
            };

            prods.unshift(newProduct);
            setMockStorage('products', prods);

            if (cat) {
                cat.productCount = (cat.productCount || 0) + 1;
                setMockStorage('categories', cats);
            }

            return { success: true, message: 'Product created successfully', data: newProduct };
        }

        if (endpoint.startsWith('/products/') && method === 'PUT') {
            const id = parseInt(endpoint.split('/')[2]);
            const prods = getMockStorage('products', DEFAULT_PRODUCTS);
            const target = prods.find(p => p.id === id);
            if (target) {
                const cats = getMockStorage('categories', DEFAULT_CATEGORIES);
                const cat = cats.find(c => c.id === body.categoryId);
                if (cat) {
                    target.categoryId = cat.id;
                    target.categoryName = cat.name;
                }
                if (body.name) target.name = body.name;
                if (body.description !== undefined) target.description = body.description;
                if (body.price) target.price = parseFloat(body.price);
                if (body.stockQuantity !== undefined) {
                    target.stockQuantity = parseInt(body.stockQuantity);
                    target.available = target.stockQuantity > 0;
                }
                if (body.unit) target.unit = body.unit;
                if (body.imageUrl) target.imageUrl = body.imageUrl;
                if (body.available !== undefined) target.available = body.available;
                setMockStorage('products', prods);
            }
            return { success: true, message: 'Product updated successfully', data: target };
        }

        if (endpoint.startsWith('/products/') && method === 'DELETE') {
            const id = parseInt(endpoint.split('/')[2]);
            let prods = getMockStorage('products', DEFAULT_PRODUCTS);
            prods = prods.filter(p => p.id !== id);
            setMockStorage('products', prods);
            return { success: true, message: 'Product deleted successfully' };
        }

        // 5. Cart
        if (endpoint === '/cart' && method === 'GET') {
            const cartItems = getMockStorage('cart_items', [
                { id: 101, productId: 1, productName: "Organic Red Tomatoes", productImage: "https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=200", price: 45.0, unit: "kg", quantity: 2, subtotal: 90.0, availableStock: 150, farmName: "Green Valley Organic Farm" }
            ]);
            const subtotal = cartItems.reduce((acc, i) => acc + (i.price * i.quantity), 0);
            const deliveryCharge = subtotal > 0 && subtotal < 500 ? 40.0 : 0.0;
            const totalAmount = subtotal + deliveryCharge;
            const totalItems = cartItems.reduce((acc, i) => acc + i.quantity, 0);

            return { success: true, data: { id: 1, items: cartItems, subtotal, deliveryCharge, totalAmount, totalItems } };
        }

        if (endpoint === '/cart/items' && method === 'POST') {
            const prods = getMockStorage('products', DEFAULT_PRODUCTS);
            const prod = prods.find(p => p.id === body.productId) || prods[0];
            const items = getMockStorage('cart_items', []);
            const existing = items.find(i => i.productId === prod.id);

            if (existing) {
                existing.quantity += (body.quantity || 1);
                existing.subtotal = existing.price * existing.quantity;
            } else {
                items.push({
                    id: Date.now(),
                    productId: prod.id,
                    productName: prod.name,
                    productImage: prod.imageUrl,
                    price: prod.price,
                    unit: prod.unit,
                    quantity: body.quantity || 1,
                    subtotal: prod.price * (body.quantity || 1),
                    availableStock: prod.stockQuantity,
                    farmName: prod.farmName
                });
            }
            setMockStorage('cart_items', items);
            return this.handleOfflineMock('/cart', { method: 'GET' });
        }

        if (endpoint.startsWith('/cart/items/') && method === 'PUT') {
            const itemId = parseInt(endpoint.split('/')[3]);
            let items = getMockStorage('cart_items', []);
            const target = items.find(i => i.id === itemId);
            if (target) {
                if (body.quantity <= 0) {
                    items = items.filter(i => i.id !== itemId);
                } else {
                    target.quantity = body.quantity;
                    target.subtotal = target.price * target.quantity;
                }
                setMockStorage('cart_items', items);
            }
            return this.handleOfflineMock('/cart', { method: 'GET' });
        }

        if (endpoint.startsWith('/cart/items/') && method === 'DELETE') {
            const itemId = parseInt(endpoint.split('/')[3]);
            let items = getMockStorage('cart_items', []);
            items = items.filter(i => i.id !== itemId);
            setMockStorage('cart_items', items);
            return this.handleOfflineMock('/cart', { method: 'GET' });
        }

        if (endpoint === '/cart/clear' && method === 'DELETE') {
            setMockStorage('cart_items', []);
            return { success: true, message: 'Cart cleared' };
        }

        // 6. Orders
        if (endpoint === '/orders' && method === 'POST') {
            const cartRes = this.handleOfflineMock('/cart', { method: 'GET' });
            const cart = cartRes.data;
            const orderNum = 'ORD-' + new Date().toISOString().slice(0,10).replace(/-/g,'') + '-' + Math.floor(1000 + Math.random() * 9000);

            const newOrder = {
                id: Date.now(),
                orderNumber: orderNum,
                customerName: body.customerName || (user ? user.name : 'Customer'),
                customerPhone: body.phone || '+91 9876543210',
                deliveryAddress: body.deliveryAddress || 'Baner Road',
                city: body.city || 'Pune',
                state: body.state || 'Maharashtra',
                pincode: body.pincode || '411045',
                totalAmount: cart.totalAmount || 540.0,
                deliveryCharge: cart.deliveryCharge || 0.0,
                orderStatus: 'ORDER_PLACED',
                orderDate: new Date().toISOString(),
                expectedDeliveryDate: new Date(Date.now() + 172800000).toISOString(),
                items: cart.items.map(i => ({
                    id: i.id,
                    productId: i.productId,
                    productName: i.productName,
                    productImage: i.productImage,
                    unit: i.unit,
                    farmName: i.farmName,
                    quantity: i.quantity,
                    price: i.price,
                    subtotal: i.subtotal
                })),
                payment: {
                    id: Date.now(),
                    paymentMethod: body.paymentMethod,
                    paymentStatus: body.paymentMethod === 'CASH_ON_DELIVERY' ? 'PENDING' : 'SUCCESS',
                    transactionId: 'TXN-' + Date.now(),
                    amount: cart.totalAmount,
                    paymentDate: new Date().toISOString()
                }
            };

            const orders = getMockStorage('orders', []);
            orders.unshift(newOrder);
            setMockStorage('orders', orders);
            setMockStorage('cart_items', []); // Clear cart

            return { success: true, message: 'Order placed', data: newOrder };
        }

        if (endpoint === '/orders' && method === 'GET') {
            const orders = getMockStorage('orders', [
                {
                    id: 1,
                    orderNumber: 'ORD-20261007-DEMO',
                    customerName: 'Rahul Sharma',
                    customerPhone: '+91 9811223344',
                    deliveryAddress: 'Flat 402, Sunshine Heights, Baner Road',
                    city: 'Pune',
                    state: 'Maharashtra',
                    pincode: '411045',
                    totalAmount: 840.0,
                    deliveryCharge: 0.0,
                    orderStatus: 'CONFIRMED',
                    orderDate: new Date(Date.now() - 14400000).toISOString(),
                    expectedDeliveryDate: new Date(Date.now() + 172800000).toISOString(),
                    items: [
                        { id: 1, productId: 1, productName: 'Organic Red Tomatoes', productImage: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=200', unit: 'kg', farmName: 'Green Valley Organic Farm', quantity: 2, price: 45.0, subtotal: 90.0 },
                        { id: 2, productId: 8, productName: 'Pure A2 Gir Cow Desi Ghee', productImage: 'https://images.unsplash.com/photo-1631451095765-2c91616fc9e6?w=200', unit: 'litre', farmName: 'Green Valley Organic Farm', quantity: 1, price: 750.0, subtotal: 750.0 }
                    ],
                    payment: { paymentStatus: 'SUCCESS', paymentMethod: 'UPI' }
                }
            ]);
            return { success: true, data: orders };
        }

        if (endpoint.startsWith('/orders/track/')) {
            const orderNum = decodeURIComponent(endpoint.split('/')[3]);
            const orders = getMockStorage('orders', []);
            const found = orders.find(o => o.orderNumber.toUpperCase() === orderNum.toUpperCase());
            if (found) return { success: true, data: found };
            // Fallback default
            return {
                success: true,
                data: {
                    id: 1,
                    orderNumber: orderNum,
                    customerName: user ? user.name : 'Rahul Sharma',
                    customerPhone: '+91 9811223344',
                    deliveryAddress: 'Baner Road',
                    city: 'Pune',
                    state: 'Maharashtra',
                    totalAmount: 840.0,
                    deliveryCharge: 0.0,
                    orderStatus: 'CONFIRMED',
                    orderDate: new Date().toISOString(),
                    expectedDeliveryDate: new Date(Date.now() + 172800000).toISOString(),
                    items: [
                        { id: 1, productName: 'Organic Red Tomatoes', productImage: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=200', unit: 'kg', farmName: 'Green Valley Organic Farm', quantity: 2, price: 45.0, subtotal: 90.0 }
                    ]
                }
            };
        }

        if (endpoint.startsWith('/orders/') && endpoint.endsWith('/status') && method === 'PUT') {
            const orderId = parseInt(endpoint.split('/')[2]);
            const orders = getMockStorage('orders', []);
            const ord = orders.find(o => o.id === orderId);
            if (ord) {
                ord.orderStatus = body.status;
                setMockStorage('orders', orders);
            }
            return { success: true, message: 'Status updated' };
        }

        // 7. Dashboards
        if (endpoint === '/seller/dashboard') {
            return {
                success: true,
                data: { totalProducts: 6, totalOrders: 14, pendingOrders: 3, completedOrders: 11, totalRevenue: 12450.0 }
            };
        }

        if (endpoint === '/admin/dashboard') {
            return {
                success: true,
                data: { totalCustomers: 120, totalSellers: 18, totalProducts: 45, totalOrders: 82, totalRevenue: 48920.0 }
            };
        }

        if (endpoint === '/customer/dashboard') {
            return {
                success: true,
                data: { totalOrders: 4, pendingOrders: 1, completedOrders: 3, totalRevenue: 1680.0 }
            };
        }

        if (endpoint === '/seller/products') {
            return this.handleOfflineMock('/products', { method: 'GET' });
        }

        if (endpoint === '/seller/orders') {
            return this.handleOfflineMock('/orders', { method: 'GET' });
        }

        if (endpoint === '/customer/orders') {
            return this.handleOfflineMock('/orders', { method: 'GET' });
        }

        if (endpoint === '/customer/profile') {
            return {
                success: true,
                data: user || { id: 1, name: 'Rahul Sharma', email: 'rahul@gmail.com', phone: '+91 9811223344', address: 'Flat 402, Sunshine Heights, Pune', role: 'ROLE_CUSTOMER' }
            };
        }

        if (endpoint === '/admin/users') {
            return {
                success: true,
                data: [
                    { id: 1, name: 'System Administrator', email: 'admin@agrifresh.com', role: 'ROLE_ADMIN', active: true },
                    { id: 2, name: 'Ramesh Patil', email: 'ramesh@farm.com', role: 'ROLE_SELLER', farmName: 'Green Valley Organic Farm', active: true },
                    { id: 3, name: 'Rahul Sharma', email: 'rahul@gmail.com', role: 'ROLE_CUSTOMER', phone: '+91 9811223344', active: true }
                ]
            };
        }

        if (endpoint.includes('/reviews') && method === 'GET') {
            return {
                success: true,
                data: [
                    { id: 1, customerName: 'Priya Verma', rating: 5, comment: 'Very fresh harvest! Delivery was super quick.', createdAt: new Date().toISOString() }
                ]
            };
        }

        return { success: true, message: 'Action executed successfully', data: null };
    },

    // Public Facades
    async login(email, password) {
        const res = await this.request('/auth/login', {
            method: 'POST',
            body: JSON.stringify({ email, password })
        });
        if (res.data && res.data.token) {
            this.setToken(res.data.token);
            this.setCurrentUser(res.data);
        }
        return res;
    },

    async register(userData) {
        const res = await this.request('/auth/register', {
            method: 'POST',
            body: JSON.stringify(userData)
        });
        if (res.data && res.data.token) {
            this.setToken(res.data.token);
            this.setCurrentUser(res.data);
        }
        return res;
    },

    async getCategories() { return await this.request('/categories'); },
    async createCategory(catData) { return await this.request('/categories', { method: 'POST', body: JSON.stringify(catData) }); },
    async getProducts() { return await this.request('/products'); },
    async getProduct(id) { return await this.request(`/products/${id}`); },
    async searchProducts(params = {}) {
        const qs = new URLSearchParams();
        for (const k in params) if (params[k]) qs.append(k, params[k]);
        return await this.request(`/products/search?${qs.toString()}`);
    },
    async createProduct(productData) { return await this.request('/products', { method: 'POST', body: JSON.stringify(productData) }); },
    async updateProduct(id, productData) { return await this.request(`/products/${id}`, { method: 'PUT', body: JSON.stringify(productData) }); },
    async deleteProduct(id) { return await this.request(`/products/${id}`, { method: 'DELETE' }); },

    async getCart() { return await this.request('/cart'); },
    async addToCart(productId, quantity = 1) { return await this.request('/cart/items', { method: 'POST', body: JSON.stringify({ productId, quantity }) }); },
    async updateCartItem(itemId, quantity) { return await this.request(`/cart/items/${itemId}`, { method: 'PUT', body: JSON.stringify({ quantity }) }); },
    async removeCartItem(itemId) { return await this.request(`/cart/items/${itemId}`, { method: 'DELETE' }); },
    async clearCart() { return await this.request('/cart/clear', { method: 'DELETE' }); },

    async placeOrder(orderData) { return await this.request('/orders', { method: 'POST', body: JSON.stringify(orderData) }); },
    async getOrders() { return await this.request('/orders'); },
    async getOrder(id) { return await this.request(`/orders/${id}`); },
    async trackOrder(orderNumber) { return await this.request(`/orders/track/${encodeURIComponent(orderNumber)}`); },
    async updateOrderStatus(id, status) { return await this.request(`/orders/${id}/status`, { method: 'PUT', body: JSON.stringify({ status }) }); },
    async cancelOrder(id) { return await this.request(`/orders/${id}/cancel`, { method: 'DELETE' }); },

    async processPayment(paymentData) { return await this.request('/payments', { method: 'POST', body: JSON.stringify(paymentData) }); },

    async getSellerProducts() { return await this.request('/seller/products'); },
    async getSellerOrders() { return await this.request('/seller/orders'); },
    async getSellerDashboard() { return await this.request('/seller/dashboard'); },

    async getCustomerProfile() { return await this.request('/customer/profile'); },
    async updateCustomerProfile(profileData) { return await this.request('/customer/profile', { method: 'PUT', body: JSON.stringify(profileData) }); },
    async getCustomerOrders() { return await this.request('/customer/orders'); },
    async getCustomerDashboard() { return await this.request('/customer/dashboard'); },

    async getAdminUsers() { return await this.request('/admin/users'); },
    async toggleUserStatus(userId) { return await this.request(`/admin/users/${userId}/status`, { method: 'PUT' }); },
    async getAdminOrders() { return await this.request('/admin/orders'); },
    async getAdminDashboard() { return await this.request('/admin/dashboard'); },

    async getReviews(productId) { return await this.request(`/products/${productId}/reviews`); },
    async addReview(productId, reviewData) { return await this.request(`/products/${productId}/reviews`, { method: 'POST', body: JSON.stringify(reviewData) }); }
};

// UI Utilities
function formatCurrency(amount) {
    if (amount === undefined || amount === null) return '₹0.00';
    return '₹' + Number(amount).toFixed(2);
}

function showToast(message, type = 'success') {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.className = 'toast-container';
        document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `<span>${type === 'success' ? '✓' : '⚠'}</span> <span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
        toast.remove();
    }, 3500);
}

// Global Nav & Session Sync
document.addEventListener('DOMContentLoaded', async () => {
    const user = AgriAPI.getCurrentUser();
    const navActions = document.getElementById('nav-actions');
    const cartBadge = document.getElementById('cart-badge');

    if (cartBadge && user && user.role === 'ROLE_CUSTOMER') {
        try {
            const cartRes = await AgriAPI.getCart();
            if (cartRes && cartRes.data) {
                cartBadge.textContent = cartRes.data.totalItems || '0';
            }
        } catch (e) {}
    }

    if (navActions) {
        if (user) {
            let dashboardLink = 'customer-dashboard.html';
            let roleLabel = 'Customer';
            if (user.role === 'ROLE_SELLER') {
                dashboardLink = 'seller-dashboard.html';
                roleLabel = 'Farmer/Seller';
            } else if (user.role === 'ROLE_ADMIN') {
                dashboardLink = 'admin-dashboard.html';
                roleLabel = 'Admin';
            }

            navActions.innerHTML = `
                <a href="cart.html" class="cart-btn" id="cart-nav-btn">
                    🛒 Cart <span class="cart-badge" id="cart-badge">0</span>
                </a>
                <a href="${dashboardLink}" class="user-badge">
                    👤 <span>${user.name.split(' ')[0]} (${roleLabel})</span>
                </a>
                <button onclick="AgriAPI.logout()" class="btn btn-outline btn-sm">Logout</button>
            `;

            try {
                const cartRes = await AgriAPI.getCart();
                const updatedBadge = document.getElementById('cart-badge');
                if (updatedBadge && cartRes && cartRes.data) {
                    updatedBadge.textContent = cartRes.data.totalItems || '0';
                }
            } catch (e) {}
        } else {
            navActions.innerHTML = `
                <a href="login.html" class="btn btn-outline btn-sm">Login</a>
                <a href="register.html" class="btn btn-primary btn-sm">Register</a>
            `;
        }
    }
});
